'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { dataProvider } from '@/lib/data-provider';
import { ReportData } from '@/types/database';
import {
  BarChart3,
  Calendar,
  Download,
  FileSpreadsheet,
  Printer,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  Phone,
  Car,
  DollarSign,
  Users,
  Receipt,
  Banknote,
  Percent,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { exportToCSV, exportToXLSX, printElement } from '@/lib/export';

const PIE_COLORS = ['#3b82f6', '#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#14b8a6', '#f43f5e'];

export function ReportsScreen() {
  const { session, showToast, t, dataVersion, theme } = useApp();

  const todayStr = new Date().toISOString().split('T')[0];
  const [periodPreset, setPeriodPreset] = useState<'today' | 'this_month' | 'last_month' | 'custom'>('this_month');
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(todayStr);

  const [report, setReport] = useState<ReportData | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const role = session?.profile.role || 'staff';
  // Manager has "both": Data entry + reports!
  const canViewReports = ['superadmin', 'superstaff', 'owner', 'manager', 'accountant'].includes(role);

  const fetchReport = () => {
    if (!canViewReports) {
      setErrorMsg(t.reports.restricted);
      return;
    }
    setErrorMsg(null);
    try {
      const data = dataProvider.getCompanyReport(startDate, endDate);
      setReport(data);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to generate report');
    }
  };

  useEffect(() => {
    fetchReport();
  }, [startDate, endDate, dataVersion, role]);

  // Handle Preset Changes
  const handlePresetChange = (preset: 'today' | 'this_month' | 'last_month' | 'custom') => {
    setPeriodPreset(preset);
    const now = new Date();

    if (preset === 'today') {
      setStartDate(todayStr);
      setEndDate(todayStr);
    } else if (preset === 'this_month') {
      const first = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      setStartDate(first);
      setEndDate(todayStr);
    } else if (preset === 'last_month') {
      const first = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0];
      const last = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0];
      setStartDate(first);
      setEndDate(last);
    }
  };

  const handleExportCSV = () => {
    if (!report) return;
    const kpisRow = [
      { Metric: 'Vehicles Count', Value: report.kpis.vehicles_count },
      { Metric: 'Accrual Revenue', Value: report.kpis.revenue },
      { Metric: 'Cash Collected', Value: report.kpis.collected },
      { Metric: 'Unpaid Revenue', Value: report.kpis.unpaid },
      { Metric: 'Customer Balances Due', Value: report.kpis.customer_balances_due },
      { Metric: 'Operating Expenses', Value: report.kpis.expenses },
      { Metric: 'Total Staff Payroll', Value: report.kpis.total_salary },
      { Metric: 'Net Profit', Value: report.kpis.net_profit },
      { Metric: 'Net Margin (%)', Value: `${(report.kpis.net_margin * 100).toFixed(1)}%` },
      { Metric: 'Cash Profit', Value: report.kpis.cash_profit },
      { Metric: 'Health Score', Value: `${report.health.score} (${report.health.status})` },
    ];
    exportToCSV(`Garage_Report_${startDate}_to_${endDate}`, kpisRow);
  };

  const handleExportXLSX = () => {
    if (!report) return;

    const sheets = [
      {
        name: 'KPIs',
        data: [
          { Metric: 'Vehicles Count', Value: report.kpis.vehicles_count },
          { Metric: 'Accrual Revenue', Value: report.kpis.revenue },
          { Metric: 'Cash Collected', Value: report.kpis.collected },
          { Metric: 'Unpaid Revenue', Value: report.kpis.unpaid },
          { Metric: 'Customer Balances Due', Value: report.kpis.customer_balances_due },
          { Metric: 'Operating Expenses', Value: report.kpis.expenses },
          { Metric: 'Total Staff Payroll', Value: report.kpis.total_salary },
          { Metric: 'Net Profit', Value: report.kpis.net_profit },
          { Metric: 'Cash Profit', Value: report.kpis.cash_profit },
          { Metric: 'Health Score', Value: report.health.score },
        ],
      },
      {
        name: 'Staff Payroll',
        data: report.staff_payroll.map((s) => ({
          Staff: s.full_name,
          Role: s.role,
          Basis: s.pay_type,
          Jobs: s.jobs_count,
          Sales: s.jobs_sales,
          PresentDays: s.present_days,
          LeaveDays: s.leave_days,
          GrossSalary: s.gross_salary,
          Advances: s.advances,
          BalanceToPay: s.balance_to_pay,
        })),
      },
      {
        name: 'Expenses by Category',
        data: report.pnl_categories.map((c) => ({
          Category: c.category,
          Amount: c.amount,
          'Percent of Revenue': `${c.percent_of_revenue}%`,
          'Percent of Expenses': `${c.percent_of_expenses}%`,
        })),
      },
      {
        name: 'Unpaid Walk-ins',
        data: report.unpaid_vehicles.map((u) => ({
          Date: u.entry_date,
          Plate: u.plate,
          Mobile: u.mobile,
          Service: u.work_type,
          Total: u.total,
          Staff: u.staff_name,
        })),
      },
    ];

    exportToXLSX(`Garage_Full_Report_${startDate}_to_${endDate}`, sheets);
  };

  if (!canViewReports) {
    return (
      <div className="max-w-4xl mx-auto p-12 text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center justify-center">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">{t.reports.restricted}</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Financial and payroll aggregate reports are confidential and available to Owner, Manager, Accountant, and Platform staff only.
        </p>
      </div>
    );
  }

  if (errorMsg) {
    return (
      <div className="max-w-4xl mx-auto p-8 text-center text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 rounded-3xl border border-rose-200 dark:border-rose-800">
        {errorMsg}
      </div>
    );
  }

  if (!report) return null;

  const kpis = report.kpis;
  const health = report.health;
  const comp = report.previous_comparison;

  const healthColor =
    health.status === 'healthy'
      ? 'text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/20'
      : health.status === 'fair'
      ? 'text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-500/30 bg-amber-50 dark:bg-amber-950/20'
      : 'text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-500/30 bg-rose-50 dark:bg-rose-950/20';

  return (
    <div id="printable-report" className="max-w-7xl mx-auto px-4 py-6 space-y-6 printable-card">
      {/* Title & Presets Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-blue-600 dark:text-blue-500" />
            {t.reports.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{t.reports.subtitle}</p>
        </div>

        {/* Action Controls: Presets, Date Picker & Exports */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Presets */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-900 rounded-xl p-1 border border-slate-200 dark:border-slate-800 text-xs font-semibold">
            <button
              onClick={() => handlePresetChange('today')}
              className={`px-3 py-1.5 rounded-lg transition ${
                periodPreset === 'today'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {t.reports.today}
            </button>
            <button
              onClick={() => handlePresetChange('this_month')}
              className={`px-3 py-1.5 rounded-lg transition ${
                periodPreset === 'this_month'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {t.reports.thisMonth}
            </button>
            <button
              onClick={() => handlePresetChange('last_month')}
              className={`px-3 py-1.5 rounded-lg transition ${
                periodPreset === 'last_month'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {t.reports.lastMonth}
            </button>
          </div>

          {/* Date Picker Range */}
          <div className="flex items-center gap-1 text-xs">
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setPeriodPreset('custom');
              }}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-200 font-medium"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setPeriodPreset('custom');
              }}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-200 font-medium"
            />
          </div>

          {/* Export Buttons */}
          <button
            onClick={handleExportCSV}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1 transition border border-slate-200 dark:border-slate-700"
            title="Export CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">CSV</span>
          </button>
          <button
            onClick={handleExportXLSX}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-emerald-700 dark:text-emerald-400 text-xs font-bold flex items-center gap-1 transition border border-slate-200 dark:border-slate-700"
            title="Export Excel"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">XLSX</span>
          </button>
          <button
            onClick={() => printElement('printable-report')}
            className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 transition shadow-sm"
            title="Print Report"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Print</span>
          </button>
        </div>
      </div>

      {/* Printable Report Header */}
      <div className="hidden print-only space-y-1 pb-4 border-b border-black">
        <h1 className="text-xl font-bold">Garage Financial & Performance Report</h1>
        <p className="text-xs">
          Period: {startDate} to {endDate}
        </p>
      </div>

      {/* KPI Cards Grid (10 Core Metrics) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {/* 1. Vehicles */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>{t.reports.kpis.vehicles}</span>
            <Car className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">{kpis.vehicles_count}</div>
          <div className="text-[10px] text-slate-500 mt-1">Avg: {kpis.avg_per_vehicle.toFixed(2)} / vehicle</div>
        </div>

        {/* 2. Accrual Revenue */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>{t.reports.kpis.revenue}</span>
            <TrendingUp className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">{kpis.revenue.toFixed(2)}</div>
          <div className="text-[10px] text-slate-500 mt-1">Accrual (Done jobs)</div>
        </div>

        {/* 3. Cash Collected */}
        <div className="p-4 rounded-3xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/30 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-emerald-700 dark:text-emerald-400 flex items-center justify-between font-medium">
            <span>{t.reports.kpis.collected}</span>
            <DollarSign className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-800 dark:text-emerald-300 mt-1">{kpis.collected.toFixed(2)}</div>
          <div className="text-[10px] text-emerald-600 dark:text-emerald-500/80 mt-1">Paid walk-ins + payments</div>
        </div>

        {/* 4. Period Unpaid */}
        <div className="p-4 rounded-3xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/30 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-amber-700 dark:text-amber-400 flex items-center justify-between font-medium">
            <span>{t.reports.kpis.unpaid}</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-800 dark:text-amber-300 mt-1">{kpis.unpaid.toFixed(2)}</div>
          <div className="text-[10px] text-amber-600 dark:text-amber-500/80 mt-1">Revenue - Collected</div>
        </div>

        {/* 5. Customer Balances Due */}
        <div className="p-4 rounded-3xl bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-800/30 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-rose-700 dark:text-rose-400 flex items-center justify-between font-medium">
            <span>{t.reports.kpis.customerBalances}</span>
            <Users className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-800 dark:text-rose-300 mt-1">{kpis.customer_balances_due.toFixed(2)}</div>
          <div className="text-[10px] text-rose-600 dark:text-rose-500/80 mt-1">Total credit accounts</div>
        </div>

        {/* 6. Operating Expenses */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>{t.reports.kpis.expenses}</span>
            <Receipt className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">{kpis.expenses.toFixed(2)}</div>
          <div className="text-[10px] text-slate-500 mt-1">
            {kpis.revenue > 0 ? `${((kpis.expenses / kpis.revenue) * 100).toFixed(1)}% of sales` : '0%'}
          </div>
        </div>

        {/* 7. Total Payroll */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>{t.reports.kpis.salary}</span>
            <Banknote className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">{kpis.total_salary.toFixed(2)}</div>
          <div className="text-[10px] text-slate-500 mt-1">Comm + Daily + Monthly</div>
        </div>

        {/* 8. Net Profit & Margin */}
        <div
          className={`p-4 rounded-3xl border shadow-sm dark:shadow-xl backdrop-blur-md ${
            kpis.net_profit >= 0
              ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-700/50'
              : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-700/50'
          }`}
        >
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between font-medium">
            <span>{t.reports.kpis.netProfit}</span>
            <Percent className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div
            className={`text-2xl font-black mt-1 ${
              kpis.net_profit >= 0 ? 'text-emerald-800 dark:text-emerald-300' : 'text-rose-700 dark:text-rose-400'
            }`}
          >
            {kpis.net_profit.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-700 dark:text-slate-300 font-semibold mt-1">
            Margin: {(kpis.net_margin * 100).toFixed(1)}%
          </div>
        </div>

        {/* 9. Cash Profit */}
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-xl backdrop-blur-md">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>{t.reports.kpis.cashProfit}</span>
            <DollarSign className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="text-2xl font-black text-blue-700 dark:text-blue-300 mt-1">{kpis.cash_profit.toFixed(2)}</div>
          <div className="text-[10px] text-slate-500 mt-1">Collected - Opex - Payroll</div>
        </div>

        {/* 10. Health Score */}
        <div className={`p-4 rounded-3xl border shadow-sm dark:shadow-xl backdrop-blur-md ${healthColor}`}>
          <div className="text-xs font-semibold flex items-center justify-between">
            <span>Health Score</span>
            <CheckCircle className="w-3.5 h-3.5" />
          </div>
          <div className="text-3xl font-black mt-1">{health.score} / 100</div>
          <div className="text-[10px] uppercase font-bold tracking-wider mt-1">{health.status}</div>
        </div>
      </div>

      {/* Business Health Score & Diagnostic Warnings */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-md dark:shadow-xl space-y-4 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              {t.reports.health.scoreTitle} ({health.score}/100 -{' '}
              {health.status === 'healthy'
                ? t.reports.health.healthy
                : health.status === 'fair'
                ? t.reports.health.fair
                : t.reports.health.atRisk}
              )
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Automated 10-point financial diagnostic engine monitoring margins, labor overhead, receivables, and growth.
            </p>
          </div>
        </div>

        {health.warnings.length === 0 ? (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/30 text-emerald-800 dark:text-emerald-300 text-xs font-medium flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{t.reports.health.noWarnings}</span>
          </div>
        ) : (
          <div className="space-y-3">
            {health.warnings.map((w, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-start justify-between gap-3 text-xs ${
                  w.level === 'red'
                    ? 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200'
                    : 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800/60 text-amber-800 dark:text-amber-200'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                        w.level === 'red' ? 'bg-rose-600 text-white' : 'bg-amber-600 text-white'
                      }`}
                    >
                      {w.level === 'red' ? 'CRITICAL ALERT' : 'WARNING'}
                    </span>
                    <strong className="text-sm font-bold text-slate-900 dark:text-white">{w.title}</strong>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300">{w.description}</p>
                </div>

                <div className="sm:max-w-xs shrink-0 p-2.5 rounded-xl bg-white/80 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800/80">
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-0.5">
                    Recommended Action:
                  </span>
                  <span className="text-slate-800 dark:text-slate-200 font-medium">{w.action}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Previous Period Comparison Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-md dark:shadow-xl transition-colors">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">{t.reports.comparison.title}</h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Comparing with previous period ({comp.prev_start_date} to {comp.prev_end_date})
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left rtl:text-right">
            <thead className="bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-2.5 px-4">{t.reports.comparison.metric}</th>
                <th className="py-2.5 px-4 text-right rtl:text-left">{t.reports.comparison.current}</th>
                <th className="py-2.5 px-4 text-right rtl:text-left">{t.reports.comparison.previous}</th>
                <th className="py-2.5 px-4 text-right rtl:text-left">{t.reports.comparison.change}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
              <tr>
                <td className="py-2.5 px-4 font-bold text-slate-800 dark:text-slate-200">Revenue (AED)</td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-bold text-slate-900 dark:text-white">
                  {kpis.revenue.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left text-slate-500 dark:text-slate-400">
                  {comp.prev_revenue.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-bold">
                  <span
                    className={
                      comp.sales_growth_pct >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                    }
                  >
                    {comp.sales_growth_pct >= 0 ? '+' : ''}
                    {comp.sales_growth_pct}%
                  </span>
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-bold text-slate-800 dark:text-slate-200">Operating Expenses</td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-bold text-slate-900 dark:text-white">
                  {kpis.expenses.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left text-slate-500 dark:text-slate-400">
                  {comp.prev_expenses.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-bold">
                  <span
                    className={
                      comp.expense_growth_pct <= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                    }
                  >
                    {comp.expense_growth_pct >= 0 ? '+' : ''}
                    {comp.expense_growth_pct}%
                  </span>
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-bold text-slate-800 dark:text-slate-200">Total Staff Payroll</td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-bold text-slate-900 dark:text-white">
                  {kpis.total_salary.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left text-slate-500 dark:text-slate-400">
                  {comp.prev_salary.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-medium text-slate-700 dark:text-slate-300">
                  {comp.prev_salary > 0
                    ? `${(((kpis.total_salary - comp.prev_salary) / comp.prev_salary) * 100).toFixed(1)}%`
                    : '-'}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-bold text-slate-800 dark:text-slate-200">Net Profit</td>
                <td
                  className={`py-2.5 px-4 text-right rtl:text-left font-bold ${
                    kpis.net_profit >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {kpis.net_profit.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left text-slate-500 dark:text-slate-400">
                  {comp.prev_net_profit.toFixed(2)}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-bold">
                  {comp.prev_net_profit !== 0 ? (
                    <span
                      className={
                        kpis.net_profit >= comp.prev_net_profit
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }
                    >
                      {(kpis.net_profit - comp.prev_net_profit).toFixed(2)} AED
                    </span>
                  ) : (
                    '-'
                  )}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-bold text-slate-800 dark:text-slate-200">Vehicles Serviced</td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-bold text-slate-900 dark:text-white">
                  {kpis.vehicles_count}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left text-slate-500 dark:text-slate-400">
                  {comp.prev_vehicles_count}
                </td>
                <td className="py-2.5 px-4 text-right rtl:text-left font-medium text-slate-700 dark:text-slate-300">
                  {comp.prev_vehicles_count > 0
                    ? `${(((kpis.vehicles_count - comp.prev_vehicles_count) / comp.prev_vehicles_count) * 100).toFixed(1)}%`
                    : '-'}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Charts Section (Recharts) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Revenue vs Expenses Line/Bar Chart */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-md dark:shadow-xl space-y-4 transition-colors">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">{t.reports.charts.dailyTitle}</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={report.daily_chart}>
                <XAxis dataKey="date" stroke={theme === 'dark' ? '#64748b' : '#94a3b8'} fontSize={11} />
                <YAxis stroke={theme === 'dark' ? '#64748b' : '#94a3b8'} fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                    borderColor: theme === 'dark' ? '#334155' : '#e2e8f0',
                    borderRadius: '0.75rem',
                    color: theme === 'dark' ? '#f8fafc' : '#0f172a',
                  }}
                />
                <Legend />
                <Bar dataKey="revenue" name="Revenue" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expenses" name="Expenses" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sales by Work Type (Donut Chart) */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-md dark:shadow-xl space-y-4 transition-colors">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">{t.reports.charts.workTypeTitle}</h2>
          <div className="h-64 w-full flex items-center justify-center">
            {report.sales_by_work_type.length === 0 ? (
              <div className="text-slate-400 text-xs">No service data for this period</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={report.sales_by_work_type}
                    dataKey="total"
                    nameKey="work_type"
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                  >
                    {report.sales_by_work_type.map((_, idx) => (
                      <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                      borderColor: theme === 'dark' ? '#334155' : '#e2e8f0',
                      borderRadius: '0.75rem',
                      color: theme === 'dark' ? '#f8fafc' : '#0f172a',
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Staff Performance & Payroll Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-md dark:shadow-xl transition-colors">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">{t.reports.staffPayroll.title}</h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Commission on price only (extra excluded) · Daily on present days · Advances deducted
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left rtl:text-right">
            <thead className="bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-2.5 px-4">{t.reports.staffPayroll.name}</th>
                <th className="py-2.5 px-4">{t.reports.staffPayroll.basis}</th>
                <th className="py-2.5 px-4 text-center">{t.reports.staffPayroll.jobs}</th>
                <th className="py-2.5 px-4 text-center">{t.reports.staffPayroll.days}</th>
                <th className="py-2.5 px-4 text-right rtl:text-left">{t.reports.staffPayroll.gross}</th>
                <th className="py-2.5 px-4 text-right rtl:text-left">{t.reports.staffPayroll.advances}</th>
                <th className="py-2.5 px-4 text-right rtl:text-left font-black">{t.reports.staffPayroll.balance}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
              {report.staff_payroll.map((s) => (
                <tr key={s.staff_id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                    <div>{s.full_name}</div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 capitalize">{s.role}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                    <span className="capitalize">{s.pay_type}</span>{' '}
                    <span className="text-slate-500 dark:text-slate-400">
                      ({s.pay_type === 'commission' ? `${s.pay_rate}%` : `${s.pay_rate} AED`})
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center font-bold text-blue-600 dark:text-blue-400">
                    {s.jobs_count}{' '}
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-normal">
                      ({s.jobs_sales.toFixed(2)} AED)
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center text-slate-700 dark:text-slate-300">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">{s.present_days}P</span> /{' '}
                    <span className="text-rose-600 dark:text-rose-400 font-bold">{s.leave_days}L</span>
                  </td>
                  <td className="py-3 px-4 text-right rtl:text-left font-bold text-slate-800 dark:text-slate-200">
                    {s.gross_salary.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right rtl:text-left text-amber-600 dark:text-amber-400 font-medium">
                    {s.advances > 0 ? `-${s.advances.toFixed(2)}` : '0.00'}
                  </td>
                  <td className="py-3 px-4 text-right rtl:text-left font-black text-sm text-emerald-600 dark:text-emerald-400">
                    {s.balance_to_pay.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Unpaid Walk-in Vehicles (Oldest First with Call Buttons) */}
      <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-md dark:shadow-xl transition-colors">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">{t.reports.unpaidVehicles.title}</h2>
          <span className="text-xs text-rose-600 dark:text-rose-400 font-semibold">
            {report.unpaid_vehicles.length} vehicles pending settlement
          </span>
        </div>

        {report.unpaid_vehicles.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs">
            {t.reports.unpaidVehicles.none}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right">
              <thead className="bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">{t.reports.unpaidVehicles.date}</th>
                  <th className="py-2.5 px-4">{t.reports.unpaidVehicles.plate}</th>
                  <th className="py-2.5 px-4">{t.reports.unpaidVehicles.service}</th>
                  <th className="py-2.5 px-4">Staff</th>
                  <th className="py-2.5 px-4 text-right rtl:text-left">{t.reports.unpaidVehicles.amount}</th>
                  <th className="py-2.5 px-4 text-right rtl:text-left">{t.common.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                {report.unpaid_vehicles.map((v) => (
                  <tr key={v.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 px-4 font-mono text-slate-500 dark:text-slate-400">{v.entry_date}</td>
                    <td className="py-2.5 px-4 font-bold text-slate-900 dark:text-white font-mono">{v.plate || 'No plate'}</td>
                    <td className="py-2.5 px-4 text-slate-700 dark:text-slate-300">
                      {v.work_type} · {v.vehicle_type}
                    </td>
                    <td className="py-2.5 px-4 text-slate-700 dark:text-slate-300">{v.staff_name}</td>
                    <td className="py-2.5 px-4 text-right rtl:text-left font-bold text-rose-600 dark:text-rose-400">
                      {v.total.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-4 text-right rtl:text-left">
                      {v.mobile ? (
                        <a
                          href={`tel:${v.mobile}`}
                          className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-[11px] inline-flex items-center gap-1 shadow-md shadow-blue-600/20"
                        >
                          <Phone className="w-3 h-3" />
                          {t.reports.unpaidVehicles.call}
                        </a>
                      ) : (
                        <span className="text-slate-400 text-[11px]">No Phone</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
