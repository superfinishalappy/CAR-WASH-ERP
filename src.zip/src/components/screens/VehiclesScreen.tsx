'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { dataProvider } from '@/lib/data-provider';
import { Job, Profile, Customer } from '@/types/database';
import {
  Car,
  Plus,
  Calendar,
  Phone,
  Hash,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Trash2,
  Edit2,
  DollarSign,
  UserCheck,
  CreditCard,
  X,
  Search,
} from 'lucide-react';

export function VehiclesScreen() {
  const { session, showToast, t, dataVersion, triggerRefresh } = useApp();

  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(todayStr);

  const [jobs, setJobs] = useState<Job[]>([]);
  const [staffList, setStaffList] = useState<Profile[]>([]);
  const [customerList, setCustomerList] = useState<Customer[]>([]);
  const [workTypes, setWorkTypes] = useState<string[]>([]);
  const [vehicleTypes, setVehicleTypes] = useState<string[]>([]);

  // Form State
  const [mobile, setMobile] = useState('');
  const [plate, setPlate] = useState('');
  const [workType, setWorkType] = useState('');
  const [vehicleType, setVehicleType] = useState('');
  const [staffId, setStaffId] = useState('');
  const [price, setPrice] = useState('');
  const [extraAmount, setExtraAmount] = useState('');
  const [customerId, setCustomerId] = useState<string>('');
  const [isPaid, setIsPaid] = useState<boolean>(true);

  // Edit / Delete Modal State
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [deletingJobId, setDeletingJobId] = useState<string | null>(null);

  // Customer Warning State
  const [selectedCustomerWarning, setSelectedCustomerWarning] = useState<string | null>(null);

  const role = session?.profile.role || 'staff';
  const isPlatform = ['superadmin', 'superstaff'].includes(role);
  const isOwner = role === 'owner' || isPlatform;
  const isManager = role === 'manager';

  const canAddSelectedDate = isOwner || selectedDate === todayStr;

  useEffect(() => {
    const j = dataProvider.getJobs(selectedDate);
    setJobs(j);

    const s = dataProvider.getCompanyProfiles().filter((p) => p.active);
    setStaffList(s);
    if (!staffId && s.length > 0) setStaffId(s[0].id);

    const c = dataProvider.getCustomers();
    setCustomerList(c);

    const settings = dataProvider.getSettings();
    setWorkTypes(settings.work_types);
    if (!workType && settings.work_types.length > 0) setWorkType(settings.work_types[0]);

    setVehicleTypes(settings.vehicle_types);
    if (!vehicleType && settings.vehicle_types.length > 0) setVehicleType(settings.vehicle_types[0]);
  }, [selectedDate, dataVersion]);

  // Check customer credit limit warning when selecting customer or typing price
  useEffect(() => {
    if (!customerId) {
      setSelectedCustomerWarning(null);
      return;
    }
    const cust = customerList.find((c) => c.id === customerId);
    if (!cust || cust.credit_limit <= 0) {
      setSelectedCustomerWarning(null);
      return;
    }

    const currentBal = cust.current_balance || 0;
    const addedAmount = (Number(price) || 0) + (Number(extraAmount) || 0);
    const projected = currentBal + addedAmount;

    if (projected > cust.credit_limit) {
      setSelectedCustomerWarning(
        `OVER CREDIT LIMIT: Customer balance will reach ${projected.toFixed(2)} (Limit: ${cust.credit_limit}). Call customer for payment!`
      );
    } else if (projected >= cust.credit_limit * 0.8) {
      setSelectedCustomerWarning(
        `NEAR CREDIT LIMIT: Balance will reach ${projected.toFixed(2)} (80% of limit ${cust.credit_limit}).`
      );
    } else {
      setSelectedCustomerWarning(null);
    }
  }, [customerId, price, extraAmount, customerList]);

  // Quick Date Selectors
  const setQuickDate = (mode: 'today' | 'yesterday') => {
    if (mode === 'today') {
      setSelectedDate(todayStr);
    } else {
      const d = new Date();
      d.setDate(d.getDate() - 1);
      setSelectedDate(d.toISOString().split('T')[0]);
    }
  };

  const handleAddJob = (e: React.FormEvent) => {
    e.preventDefault();

    if (!canAddSelectedDate) {
      showToast(t.vehicles.todayOnlyNotice, 'error');
      return;
    }

    if (!workType || !vehicleType || !staffId || !price) {
      showToast('Please fill in work type, vehicle type, staff, and price.', 'warning');
      return;
    }

    const res = dataProvider.addJob({
      entry_date: selectedDate,
      plate,
      mobile,
      work_type: workType,
      vehicle_type: vehicleType,
      staff_id: staffId,
      price: Number(price),
      extra_amount: Number(extraAmount) || 0,
      customer_id: customerId || null,
      is_paid: customerId ? false : isPaid,
    });

    if (res.success) {
      showToast('Vehicle order recorded successfully!', 'success');
      // Reset entry form
      setPlate('');
      setMobile('');
      setPrice('');
      setExtraAmount('');
      setCustomerId('');
      setIsPaid(true);
      triggerRefresh();
    } else {
      showToast(res.error || 'Failed to record vehicle', 'error');
    }
  };

  const handleUpdateJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingJob) return;

    const res = dataProvider.updateJob(editingJob.id, {
      plate: editingJob.plate || '',
      mobile: editingJob.mobile || '',
      work_type: editingJob.work_type,
      vehicle_type: editingJob.vehicle_type,
      staff_id: editingJob.staff_id,
      price: editingJob.price,
      extra_amount: editingJob.extra_amount,
      customer_id: editingJob.customer_id,
      is_paid: editingJob.is_paid,
      entry_date: editingJob.entry_date,
    });

    if (res.success) {
      showToast('Vehicle updated successfully', 'success');
      setEditingJob(null);
      triggerRefresh();
    } else {
      showToast(res.error || 'Failed to update vehicle', 'error');
    }
  };

  const handleDeleteJob = (id: string) => {
    const res = dataProvider.deleteJob(id);
    if (res.success) {
      showToast('Vehicle record deleted', 'info');
      setDeletingJobId(null);
      triggerRefresh();
    } else {
      showToast(res.error || 'Failed to delete record', 'error');
    }
  };

  // Day Totals
  const count = jobs.length;
  const totalRev = jobs.reduce((sum, j) => sum + j.total, 0);
  const paidRev = jobs.filter((j) => j.customer_id === null && j.is_paid).reduce((sum, j) => sum + j.total, 0);
  const unpaidRev = jobs.filter((j) => j.customer_id === null && !j.is_paid).reduce((sum, j) => sum + j.total, 0);
  const creditRev = jobs.filter((j) => j.customer_id !== null).reduce((sum, j) => sum + j.total, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Screen Title & Date Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <Car className="w-6 h-6 text-blue-600 dark:text-blue-500" />
            {t.vehicles.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{t.vehicles.subtitle}</p>
        </div>

        {/* Date Selector Pills */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setQuickDate('today')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              selectedDate === todayStr
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {t.vehicles.today}
          </button>
          <button
            onClick={() => setQuickDate('yesterday')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              selectedDate !== todayStr
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {t.vehicles.yesterday}
          </button>
          <div className="relative">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-sm backdrop-blur-md">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">{t.vehicles.count}</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">{count}</div>
        </div>
        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-sm backdrop-blur-md">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">{t.vehicles.totalRevenue}</div>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">{totalRev.toFixed(2)}</div>
        </div>
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 shadow-sm backdrop-blur-md">
          <div className="text-xs text-emerald-700 dark:text-emerald-400 font-medium">{t.vehicles.paid}</div>
          <div className="text-xl font-bold text-emerald-800 dark:text-emerald-300 mt-1">{paidRev.toFixed(2)}</div>
        </div>
        <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-800/40 shadow-sm backdrop-blur-md">
          <div className="text-xs text-rose-700 dark:text-rose-400 font-medium">{t.vehicles.unpaid} / Credit</div>
          <div className="text-xl font-bold text-rose-800 dark:text-rose-300 mt-1">{(unpaidRev + creditRev).toFixed(2)}</div>
        </div>
      </div>

      {/* Fast Cashier Entry Form Card */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-md dark:shadow-xl space-y-4 transition-colors">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Plus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            {t.vehicles.addVehicle} ({selectedDate})
          </h2>
          {!canAddSelectedDate && (
            <span className="text-xs text-amber-700 dark:text-amber-400 font-medium bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/40 px-2.5 py-0.5 rounded-full">
              Past Date (Owner Only)
            </span>
          )}
        </div>

        {selectedCustomerWarning && (
          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/70 border border-amber-300 dark:border-amber-600/70 text-amber-800 dark:text-amber-200 text-xs font-semibold flex items-center gap-2 animate-bounce">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400" />
            <span>{selectedCustomerWarning}</span>
          </div>
        )}

        <form onSubmit={handleAddJob} className="space-y-4">
          {/* Quick Category & Vehicle Type Pill Selectors */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">{t.vehicles.workType}</label>
            <div className="flex flex-wrap gap-2">
              {workTypes.map((wt) => (
                <button
                  type="button"
                  key={wt}
                  onClick={() => setWorkType(wt)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    workType === wt
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                      : 'bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-transparent'
                  }`}
                >
                  {wt}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">{t.vehicles.vehicleType}</label>
            <div className="flex flex-wrap gap-2">
              {vehicleTypes.map((vt) => (
                <button
                  type="button"
                  key={vt}
                  onClick={() => setVehicleType(vt)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    vehicleType === vt
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-transparent'
                  }`}
                >
                  {vt}
                </button>
              ))}
            </div>
          </div>

          {/* Form Inputs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {/* Plate Number */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.vehicles.plate}</label>
              <div className="relative">
                <Hash className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={plate}
                  onChange={(e) => setPlate(e.target.value.toUpperCase())}
                  placeholder={t.vehicles.platePlaceholder}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm uppercase text-slate-900 dark:text-slate-100 font-mono tracking-wider focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Mobile Number */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.vehicles.mobile}</label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="tel"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder={t.vehicles.mobilePlaceholder}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm text-slate-900 dark:text-slate-100 focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Handling Staff Dropdown */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.vehicles.handlingStaff}</label>
              <select
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm text-slate-900 dark:text-slate-100 focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
                required
              >
                {staffList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.full_name} ({s.pay_type === 'commission' ? `${s.pay_rate}%` : s.pay_type})
                  </option>
                ))}
              </select>
            </div>

            {/* Base Price */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.vehicles.price}</label>
              <div className="relative">
                <DollarSign className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm font-bold text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            {/* Extra Amount (Polish, Detailing, etc.) */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.vehicles.extraAmount}</label>
              <input
                type="number"
                step="0.5"
                min="0"
                value={extraAmount}
                onChange={(e) => setExtraAmount(e.target.value)}
                placeholder="Optional extra"
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm text-slate-900 dark:text-slate-100 focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Customer Account (Credit) */}
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.vehicles.customerAccount}</label>
              <select
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm text-slate-900 dark:text-slate-100 focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
              >
                <option value="">-- Walk-in Customer --</option>
                {customerList.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} (Limit: {c.credit_limit})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Payment Toggle (Only active if Walk-in) */}
          {!customerId ? (
            <div className="flex items-center gap-3 pt-2">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">Walk-in Payment:</span>
              <button
                type="button"
                onClick={() => setIsPaid(true)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  isPaid
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                {t.vehicles.walkInPaid}
              </button>
              <button
                type="button"
                onClick={() => setIsPaid(false)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  !isPaid
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                {t.vehicles.walkInUnpaid}
              </button>
            </div>
          ) : (
            <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/40 text-blue-800 dark:text-blue-300 text-xs font-medium flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Credit account job: Automatically saved to customer ledger as credit.</span>
            </div>
          )}

          {/* Submit Order Button */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">
            <div className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              {t.vehicles.total}:{' '}
              <span className="text-lg font-black text-blue-600 dark:text-blue-400">
                {((Number(price) || 0) + (Number(extraAmount) || 0)).toFixed(2)}
              </span>
            </div>
            <button
              type="submit"
              disabled={!canAddSelectedDate}
              className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 flex items-center gap-2 transition disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              {t.vehicles.submitJob}
            </button>
          </div>
        </form>
      </div>

      {/* Selected Day's Vehicles List Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-md dark:shadow-xl transition-colors">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white tracking-wide">
            Registered Vehicles ({jobs.length})
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">Date: {selectedDate}</span>
        </div>

        {jobs.length === 0 ? (
          <div className="p-10 text-center text-slate-500 text-sm">
            {t.vehicles.noVehicles}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left rtl:text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-950/60 text-slate-600 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Plate / Mobile</th>
                  <th className="py-3 px-4">Service</th>
                  <th className="py-3 px-4">Staff</th>
                  <th className="py-3 px-4">Value (Price + Extra)</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4 text-right rtl:text-left">{t.common.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                {jobs.map((job) => {
                  const isCredit = Boolean(job.customer_id);
                  const isSameDay = job.entry_date === todayStr;
                  const canEdit = isOwner || isSameDay;
                  const canDelete = isOwner || (isManager && isSameDay);

                  return (
                    <tr key={job.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4">
                        <div className="font-mono font-bold text-slate-900 dark:text-slate-200">
                          {job.plate || 'NO PLATE'}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">{job.mobile || '-'}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-900 dark:text-white">{job.work_type}</span>
                        <span className="text-slate-500 dark:text-slate-400 text-[11px] block">{job.vehicle_type}</span>
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-700 dark:text-slate-300">
                        {job.staff_name}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                          {job.total.toFixed(2)}
                        </div>
                        {job.extra_amount > 0 && (
                          <div className="text-[10px] text-slate-500 dark:text-slate-400">
                            ({job.price} + {job.extra_amount} extra)
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {isCredit ? (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400 border border-blue-200 dark:border-blue-500/20">
                            Credit · {job.customer_name}
                          </span>
                        ) : job.is_paid ? (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20">
                            Paid Walk-in
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20">
                            Unpaid Walk-in
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right rtl:text-left space-x-2 rtl:space-x-reverse">
                        {canEdit && (
                          <button
                            onClick={() => setEditingJob(job)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                            title={t.vehicles.editVehicle}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {canDelete && (
                          <button
                            onClick={() => setDeletingJobId(job.id)}
                            className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800/30"
                            title={t.vehicles.deleteVehicle}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Vehicle Modal */}
      {editingJob && (
        <div className="fixed inset-0 z-50 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Edit Vehicle Entry</h3>
              <button
                onClick={() => setEditingJob(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateJob} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1 font-semibold">Plate Number</label>
                  <input
                    type="text"
                    value={editingJob.plate || ''}
                    onChange={(e) => setEditingJob({ ...editingJob, plate: e.target.value.toUpperCase() })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1 font-semibold">Mobile</label>
                  <input
                    type="tel"
                    value={editingJob.mobile || ''}
                    onChange={(e) => setEditingJob({ ...editingJob, mobile: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1 font-semibold">Work Type</label>
                  <select
                    value={editingJob.work_type}
                    onChange={(e) => setEditingJob({ ...editingJob, work_type: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white"
                  >
                    {workTypes.map((w) => (
                      <option key={w} value={w}>
                        {w}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1 font-semibold">Vehicle Type</label>
                  <select
                    value={editingJob.vehicle_type}
                    onChange={(e) => setEditingJob({ ...editingJob, vehicle_type: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white"
                  >
                    {vehicleTypes.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1 font-semibold">Base Price</label>
                  <input
                    type="number"
                    value={editingJob.price}
                    onChange={(e) => setEditingJob({ ...editingJob, price: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-600 dark:text-slate-400 block mb-1 font-semibold">Extra Amount</label>
                  <input
                    type="number"
                    value={editingJob.extra_amount}
                    onChange={(e) => setEditingJob({ ...editingJob, extra_amount: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-600 dark:text-slate-400 block mb-1 font-semibold">Assigned Staff</label>
                <select
                  value={editingJob.staff_id}
                  onChange={(e) => setEditingJob({ ...editingJob, staff_id: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-white"
                >
                  {staffList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.full_name}
                    </option>
                  ))}
                </select>
              </div>

              {!editingJob.customer_id && (
                <div className="flex items-center gap-3 pt-2">
                  <span className="text-slate-600 dark:text-slate-400 font-medium">Payment:</span>
                  <label className="flex items-center gap-2 cursor-pointer text-slate-800 dark:text-slate-200">
                    <input
                      type="radio"
                      name="editIsPaid"
                      checked={editingJob.is_paid}
                      onChange={() => setEditingJob({ ...editingJob, is_paid: true })}
                    />
                    Paid
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-slate-800 dark:text-slate-200">
                    <input
                      type="radio"
                      name="editIsPaid"
                      checked={!editingJob.is_paid}
                      onChange={() => setEditingJob({ ...editingJob, is_paid: false })}
                    />
                    Unpaid
                  </label>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingJob(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold border border-slate-200 dark:border-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingJobId && (
        <div className="fixed inset-0 z-50 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-50 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">{t.vehicles.deleteVehicle}</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">{t.vehicles.deleteConfirm}</p>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setDeletingJobId(null)}
                className="py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs border border-slate-200 dark:border-slate-700"
              >
                {t.common.cancel}
              </button>
              <button
                onClick={() => handleDeleteJob(deletingJobId)}
                className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                {t.common.delete}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
