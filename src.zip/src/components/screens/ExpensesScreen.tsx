'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { dataProvider } from '@/lib/data-provider';
import { Expense } from '@/types/database';
import {
  Receipt,
  Plus,
  Calendar,
  Trash2,
  DollarSign,
  Tag,
  FileText,
  Clock,
  Filter,
} from 'lucide-react';

export function ExpensesScreen() {
  const { session, showToast, t, dataVersion, triggerRefresh } = useApp();

  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(todayStr);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [categories, setCategories] = useState<string[]>([]);

  // Form State
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');

  const role = session?.profile.role || 'staff';
  const isOwner = role === 'owner' || ['superadmin', 'superstaff'].includes(role);
  const canDeleteRole = isOwner || ['manager', 'accountant'].includes(role);

  useEffect(() => {
    const list = dataProvider.getExpenses(selectedDate);
    setExpenses(list);

    const s = dataProvider.getSettings();
    setCategories(s.expense_categories);
    if (!category && s.expense_categories.length > 0) {
      setCategory(s.expense_categories[0]);
    }
  }, [selectedDate, dataVersion]);

  const canAddSelectedDate = isOwner || selectedDate === todayStr;

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();

    if (!canAddSelectedDate) {
      showToast('Non-owners can only add expenses for today.', 'error');
      return;
    }

    if (!category || !amount) {
      showToast('Please select category and enter amount', 'warning');
      return;
    }

    const res = dataProvider.addExpense({
      entry_date: selectedDate,
      category,
      description,
      amount: Number(amount),
    });

    if (res.success) {
      showToast('Expense recorded successfully!', 'success');
      setDescription('');
      setAmount('');
      triggerRefresh();
    } else {
      showToast(res.error || 'Failed to record expense', 'error');
    }
  };

  const handleDeleteExpense = (exp: Expense) => {
    const isSameDay = exp.entry_date === todayStr;
    const canDelete = isOwner || (canDeleteRole && isSameDay);

    if (!canDelete) {
      showToast('You do not have permission to delete this expense.', 'error');
      return;
    }

    const res = dataProvider.deleteExpense(exp.id);
    if (res.success) {
      showToast('Expense deleted', 'info');
      triggerRefresh();
    } else {
      showToast(res.error || 'Failed to delete expense', 'error');
    }
  };

  const totalExpense = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Title & Date Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <Receipt className="w-6 h-6 text-blue-600 dark:text-blue-500" />
            {t.expenses.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{t.expenses.subtitle}</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSelectedDate(todayStr)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              selectedDate === todayStr
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {t.vehicles.today}
          </button>
          <div className="relative">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-medium focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Add Expense Form Card */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-md dark:shadow-xl space-y-4 transition-colors">
        <h2 className="text-sm font-bold text-slate-900 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
          <Plus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          {t.expenses.addExpense} ({selectedDate})
        </h2>

        <form onSubmit={handleAddExpense} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Category Dropdown */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.expenses.category}</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm text-slate-900 dark:text-slate-100 focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
              required
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Amount */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.expenses.amount}</label>
            <div className="relative">
              <DollarSign className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="number"
                step="0.5"
                min="0.5"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm font-bold text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.expenses.description}</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Microfiber cloths, car shampoo batch"
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-sm text-slate-900 dark:text-slate-100 focus:bg-white dark:focus:bg-slate-950 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="sm:col-span-3 flex justify-end pt-2">
            <button
              type="submit"
              disabled={!canAddSelectedDate}
              className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 transition disabled:opacity-50"
            >
              {t.expenses.saveExpense}
            </button>
          </div>
        </form>
      </div>

      {/* Expenses Table */}
      <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-md dark:shadow-xl transition-colors">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="font-bold text-sm text-slate-900 dark:text-white">Expenses for {selectedDate}</div>
          <div className="text-sm font-black text-rose-600 dark:text-rose-400">
            {t.expenses.totalExpenses}: {totalExpense.toFixed(2)}
          </div>
        </div>

        {expenses.length === 0 ? (
          <div className="p-10 text-center text-slate-500 text-sm">
            {t.expenses.noExpenses}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right">
              <thead className="bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">{t.expenses.category}</th>
                  <th className="py-3 px-4">{t.expenses.description}</th>
                  <th className="py-3 px-4 text-right rtl:text-left">{t.expenses.amount}</th>
                  <th className="py-3 px-4 text-right rtl:text-left">{t.common.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {expenses.map((exp) => {
                  const isSameDay = exp.entry_date === todayStr;
                  const canDelete = isOwner || (canDeleteRole && isSameDay);

                  return (
                    <tr key={exp.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-slate-200">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200">
                          {exp.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{exp.description || '-'}</td>
                      <td className="py-3 px-4 text-right rtl:text-left font-black text-rose-600 dark:text-rose-400 text-sm">
                        {exp.amount.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right rtl:text-left">
                        {canDelete && (
                          <button
                            onClick={() => handleDeleteExpense(exp)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 dark:hover:bg-rose-900/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800/30"
                            title="Delete expense"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
