'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import {
  Wrench,
  Sun,
  Moon,
  Globe,
  LogOut,
  Building2,
  ShieldAlert,
  ArrowLeftRight,
  User,
  Sparkles,
  AlertTriangle,
} from 'lucide-react';
import { dataProvider } from '@/lib/data-provider';

export function Header() {
  const { session, language, setLanguage, theme, toggleTheme, logout, actingCompany, setActingCompany, setActiveTab, t } = useApp();

  if (!session) return null;

  const role = session.profile.role;
  const isPlatform = ['superadmin', 'superstaff'].includes(role);
  const company = isPlatform ? actingCompany : session.company;

  // Expiry check for warning banner (<= 7 days)
  let daysLeft: number | null = null;
  if (company && company.valid_until) {
    const valid = new Date(company.valid_until);
    const now = new Date();
    daysLeft = Math.ceil((valid.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  }

  const showExpiryWarning = daysLeft !== null && daysLeft <= 7 && daysLeft >= 0;

  const roleBadgeColors: Record<string, string> = {
    superadmin: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    superstaff: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    owner: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    manager: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    accountant: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    staff: 'bg-slate-500/20 text-slate-300 border-slate-500/30',
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800/80 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md transition-colors duration-200">
      {/* 1. Super Admin "Acting in Company" Sticky Banner */}
      {isPlatform && actingCompany && (
        <div className="bg-gradient-to-r from-indigo-900/90 via-purple-900/90 to-blue-900/90 px-4 py-2 border-b border-indigo-700/50 flex flex-wrap items-center justify-between gap-2 text-xs md:text-sm text-indigo-100">
          <div className="flex items-center gap-2 font-medium">
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>
              {t.banner.actingIn} <strong className="text-white font-bold">{actingCompany.name}</strong> ({actingCompany.code})
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setActingCompany(null);
                setActiveTab('admin');
              }}
              className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 text-white font-medium flex items-center gap-1.5 transition text-xs"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              {t.banner.backToAdmin}
            </button>
          </div>
        </div>
      )}

      {/* 2. Owner 7-day Pre-Expiry Warning Banner */}
      {showExpiryWarning && (
        <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 dark:from-amber-950/90 dark:to-orange-950/90 border-b border-amber-500/30 dark:border-amber-600/40 px-4 py-2 flex items-center justify-between text-xs md:text-sm text-amber-800 dark:text-amber-200">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0" />
            <span>
              {t.banner.expiryWarning.replace('{days}', String(daysLeft))}
            </span>
          </div>
          {isPlatform && (
            <button
              onClick={() => {
                if (company) {
                  dataProvider.setSubscription(company.id, 'add_30_days');
                }
              }}
              className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-800 dark:text-amber-200 border border-amber-500/40 text-xs font-semibold"
            >
              +30 Days Now
            </button>
          )}
        </div>
      )}

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo and Workshop Info */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base md:text-lg tracking-tight text-slate-900 dark:text-white">
                {company ? company.name : t.appName}
              </span>
              {company && (
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-200 dark:border-slate-700">
                  {company.code}
                </span>
              )}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 hidden xs:block">
              {company ? `${company.currency} · ${company.timezone}` : t.tagline}
            </div>
          </div>
        </div>

        {/* User Role, Theme, Language, Logout Actions */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* User Badge */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <User className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300 max-w-[120px] truncate">
              {session.profile.full_name}
            </span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold border ${roleBadgeColors[role] || 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'}`}>
              {role}
            </span>
          </div>

          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
            title="Switch Language"
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 transition flex items-center gap-1.5 text-xs font-semibold"
          >
            <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>{language === 'en' ? 'عربي' : 'EN'}</span>
          </button>

          {/* Theme Toggle (Light / Dark) */}
          <button
            onClick={toggleTheme}
            title={theme === 'dark' ? 'Switch to Bright Mode' : 'Switch to Dark Mode'}
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 transition shadow-sm"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-600" />
            )}
          </button>

          {/* Logout */}
          <button
            onClick={logout}
            title={t.nav.signOut}
            className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-300 border border-rose-200 dark:border-rose-800/40 transition"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
