'use client';

import React from 'react';
import { useApp, NavTab } from '@/context/AppContext';
import {
  Car,
  Users,
  Receipt,
  Banknote,
  CalendarCheck,
  Settings,
  BarChart3,
  Building,
} from 'lucide-react';

export function Navigation() {
  const { session, activeTab, setActiveTab, t } = useApp();

  if (!session) return null;

  const role = session.profile.role;
  const isPlatform = ['superadmin', 'superstaff'].includes(role);
  // Manager has "both": Data entry + reports!
  const canReports = ['superadmin', 'superstaff', 'owner', 'manager', 'accountant'].includes(role);
  const canTeam = ['superadmin', 'superstaff', 'owner', 'manager'].includes(role);

  interface NavItem {
    id: NavTab;
    label: string;
    icon: React.ReactNode;
    visible: boolean;
  }

  const items: NavItem[] = [
    {
      id: 'admin' as NavTab,
      label: t.nav.allCompanies,
      icon: <Building className="w-5 h-5" />,
      visible: isPlatform,
    },
    {
      id: 'vehicles' as NavTab,
      label: t.nav.vehicles,
      icon: <Car className="w-5 h-5" />,
      visible: true,
    },
    {
      id: 'customers' as NavTab,
      label: t.nav.customers,
      icon: <Users className="w-5 h-5" />,
      visible: true,
    },
    {
      id: 'expenses' as NavTab,
      label: t.nav.expenses,
      icon: <Receipt className="w-5 h-5" />,
      visible: true,
    },
    {
      id: 'advances' as NavTab,
      label: t.nav.advances,
      icon: <Banknote className="w-5 h-5" />,
      visible: true,
    },
    {
      id: 'attendance' as NavTab,
      label: t.nav.attendance,
      icon: <CalendarCheck className="w-5 h-5" />,
      visible: true,
    },
    {
      id: 'team' as NavTab,
      label: t.nav.team,
      icon: <Settings className="w-5 h-5" />,
      visible: canTeam,
    },
    {
      id: 'reports' as NavTab,
      label: t.nav.reports,
      icon: <BarChart3 className="w-5 h-5" />,
      visible: canReports,
    },
  ].filter((item) => item.visible);

  return (
    <>
      {/* Desktop Horizontal Tabs */}
      <nav className="hidden md:block bg-white/90 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800/80 sticky top-16 z-30 backdrop-blur-md transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-1 rtl:space-x-reverse py-2 overflow-x-auto no-scrollbar">
            {items.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                    active
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation Bar (Horizontally scrollable to display all tabs) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-950/95 border-t border-slate-200 dark:border-slate-800/90 backdrop-blur-lg safe-bottom transition-colors duration-200">
        <div className="flex items-center justify-around h-16 px-1 overflow-x-auto no-scrollbar">
          {items.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center min-w-[56px] py-1 text-[11px] font-medium transition shrink-0 ${
                  active ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <div
                  className={`p-1 rounded-xl transition ${
                    active ? 'bg-blue-50 dark:bg-blue-600/20 text-blue-600 dark:text-blue-400' : ''
                  }`}
                >
                  {item.icon}
                </div>
                <span className="truncate max-w-[64px] text-[10px] mt-0.5">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
