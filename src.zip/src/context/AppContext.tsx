'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserSession, Company } from '@/types/database';
import { Language, translations } from '@/lib/i18n';
import { dataProvider } from '@/lib/data-provider';

export type NavTab = 'vehicles' | 'customers' | 'expenses' | 'advances' | 'attendance' | 'team' | 'reports' | 'admin';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

interface AppContextType {
  session: UserSession | null;
  setSession: (s: UserSession | null) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  t: (typeof translations)['en'];
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  actingCompany: Company | null;
  setActingCompany: (c: Company | null) => void;
  dataVersion: number;
  triggerRefresh: () => void;
  logout: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [session, setSessionState] = useState<UserSession | null>(null);
  const [language, setLanguageState] = useState<Language>('en');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [activeTab, setActiveTab] = useState<NavTab>('vehicles');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [dataVersion, setDataVersion] = useState(0);

  // Initialize session and theme from local storage
  useEffect(() => {
    const cur = dataProvider.getCurrentSession();
    if (cur) {
      setSessionState(cur);
      if (['superadmin', 'superstaff'].includes(cur.profile.role)) {
        setActiveTab('admin');
      } else {
        setActiveTab('vehicles');
      }
    }

    const savedLang = localStorage.getItem('garage_erp_lang') as Language;
    if (savedLang === 'en' || savedLang === 'ar') {
      setLanguageState(savedLang);
      document.documentElement.dir = savedLang === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = savedLang;
    }

    const savedTheme = localStorage.getItem('garage_erp_theme') as 'dark' | 'light';
    if (savedTheme) {
      setTheme(savedTheme);
      if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } else {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('garage_erp_lang', lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    localStorage.setItem('garage_erp_theme', next);
    if (next === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const setSession = (s: UserSession | null) => {
    setSessionState(s);
    if (s && ['superadmin', 'superstaff'].includes(s.profile.role)) {
      setActiveTab('admin');
    } else if (s) {
      setActiveTab('vehicles');
    }
  };

  const setActingCompany = (c: Company | null) => {
    dataProvider.setActingCompany(c?.id || null);
    setSessionState(dataProvider.getCurrentSession());
    triggerRefresh();
  };

  const showToast = (message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const triggerRefresh = () => {
    setDataVersion((v) => v + 1);
  };

  const logout = () => {
    dataProvider.logout();
    setSessionState(null);
    showToast('Signed out successfully', 'info');
  };

  const t = translations[language];

  const actingCompany = session?.actingCompany || null;

  return (
    <AppContext.Provider
      value={{
        session,
        setSession,
        language,
        setLanguage,
        theme,
        toggleTheme,
        activeTab,
        setActiveTab,
        t,
        toasts,
        showToast,
        actingCompany,
        setActingCompany,
        dataVersion,
        triggerRefresh,
        logout,
      }}
    >
      {children}
      {/* Toast Notifications Overlay */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto px-4 py-3 rounded-xl shadow-xl text-sm font-medium flex items-center justify-between border transition-all transform animate-in slide-in-from-bottom-2 ${
              toast.type === 'error'
                ? 'bg-rose-950/95 text-rose-200 border-rose-800'
                : toast.type === 'success'
                ? 'bg-emerald-950/95 text-emerald-200 border-emerald-800'
                : toast.type === 'warning'
                ? 'bg-amber-950/95 text-amber-200 border-amber-800'
                : 'bg-slate-900/95 text-slate-100 border-slate-700'
            }`}
          >
            <span>{toast.message}</span>
          </div>
        ))}
      </div>
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
