import {
  Company,
  Profile,
  Customer,
  Job,
  Expense,
  Advance,
  Attendance,
  CustomerPayment,
  CompanySettings,
  AuditLogEntry,
  ReportData,
  UserSession,
  DiagnosticWarning,
  AppRole,
} from '@/types/database';
import {
  INITIAL_COMPANIES,
  INITIAL_PROFILES,
  INITIAL_CUSTOMERS,
  INITIAL_JOBS,
  INITIAL_EXPENSES,
  INITIAL_ADVANCES,
  INITIAL_ATTENDANCE,
  INITIAL_CUSTOMER_PAYMENTS,
  INITIAL_SETTINGS,
  INITIAL_AUDIT_LOG,
} from '@/lib/mock-data';

// Storage keys for client-side persistence
const STORAGE_PREFIX = 'garage_erp_';

function isBrowser(): boolean {
  return typeof window !== 'undefined';
}

function loadState<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback;
  try {
    const data = localStorage.getItem(STORAGE_PREFIX + key);
    return data ? JSON.parse(data) : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveState<T>(key: string, data: T): void {
  if (!isBrowser()) return;
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save state:', e);
  }
}

export class DataProvider {
  private companies: Company[];
  private profiles: Profile[];
  private customers: Customer[];
  private jobs: Job[];
  private expenses: Expense[];
  private advances: Advance[];
  private attendance: Attendance[];
  private customerPayments: CustomerPayment[];
  private settings: Record<string, CompanySettings>;
  private auditLog: AuditLogEntry[];
  private currentSession: UserSession | null = null;

  constructor() {
    this.companies = loadState('companies', INITIAL_COMPANIES);
    this.profiles = loadState('profiles', INITIAL_PROFILES);
    this.customers = loadState('customers', INITIAL_CUSTOMERS);
    this.jobs = loadState('jobs', INITIAL_JOBS);
    this.expenses = loadState('expenses', INITIAL_EXPENSES);
    this.advances = loadState('advances', INITIAL_ADVANCES);
    this.attendance = loadState('attendance', INITIAL_ATTENDANCE);
    this.customerPayments = loadState('customer_payments', INITIAL_CUSTOMER_PAYMENTS);
    this.settings = loadState('settings', INITIAL_SETTINGS);
    this.auditLog = loadState('audit_log', INITIAL_AUDIT_LOG);
    this.currentSession = loadState('session', null);
  }

  private persist() {
    saveState('companies', this.companies);
    saveState('profiles', this.profiles);
    saveState('customers', this.customers);
    saveState('jobs', this.jobs);
    saveState('expenses', this.expenses);
    saveState('advances', this.advances);
    saveState('attendance', this.attendance);
    saveState('customer_payments', this.customerPayments);
    saveState('settings', this.settings);
    saveState('audit_log', this.auditLog);
    saveState('session', this.currentSession);
  }

  // Session & Authentication
  public getCurrentSession(): UserSession | null {
    return this.currentSession;
  }

  public setActingCompany(companyId: string | null): void {
    if (!this.currentSession) return;
    const isPlatform = ['superadmin', 'superstaff'].includes(this.currentSession.profile.role);
    if (!isPlatform) return;

    if (!companyId) {
      this.currentSession.actingCompanyId = null;
      this.currentSession.actingCompany = null;
    } else {
      const company = this.companies.find((c) => c.id === companyId);
      if (company) {
        this.currentSession.actingCompanyId = company.id;
        this.currentSession.actingCompany = company;
      }
    }
    this.persist();
  }

  public getEffectiveCompanyId(): string | null {
    if (!this.currentSession) return null;
    const role = this.currentSession.profile.role;
    if (['superadmin', 'superstaff'].includes(role)) {
      return this.currentSession.actingCompanyId || null;
    }
    return this.currentSession.profile.company_id;
  }

  public login(companyCode: string, username: string, password: string): { success: boolean; session?: UserSession; error?: string; isExpired?: boolean } {
    const codeUpper = companyCode.trim().toUpperCase();
    const userClean = username.trim().toLowerCase();

    // 1. Platform Login (Company Code: ADMIN)
    if (codeUpper === 'ADMIN') {
      const profile = this.profiles.find((p) => p.username.toLowerCase() === userClean && ['superadmin', 'superstaff'].includes(p.role));
      if (!profile || !profile.active) {
        return { success: false, error: 'Invalid Super Admin/Staff credentials' };
      }

      this.currentSession = {
        user: {
          id: profile.id,
          email: `${userClean}@admin.erp.local`,
          username: profile.username,
          company_code: 'ADMIN',
        },
        profile,
        company: null,
      };
      this.persist();
      return { success: true, session: this.currentSession };
    }

    // 2. Company Login
    const company = this.companies.find((c) => c.code.toUpperCase() === codeUpper);
    if (!company) {
      return { success: false, error: 'Company ID not found.' };
    }

    const profile = this.profiles.find((p) => p.company_id === company.id && p.username.toLowerCase() === userClean);
    if (!profile || !profile.active) {
      return { success: false, error: 'Invalid username or password.' };
    }

    // 3. Subscription Validity Check (§1 & §3)
    // When a company's subscription date passes or it is inactive, all services stop automatically!
    const todayStr = new Date().toISOString().split('T')[0];
    const isExpired = company.valid_until < todayStr || !company.active;

    if (isExpired) {
      return {
        success: false,
        error: 'Subscription expired. Contact your provider.',
        isExpired: true,
      };
    }

    this.currentSession = {
      user: {
        id: profile.id,
        email: `${userClean}@${company.code.toLowerCase()}.erp.local`,
        username: profile.username,
        company_code: company.code,
      },
      profile,
      company,
    };
    this.persist();
    return { success: true, session: this.currentSession };
  }

  public logout(): void {
    this.currentSession = null;
    this.persist();
  }

  // Permissions Enforcement Matrix (§3)
  public isSameDay(entryDate: string): boolean {
    const todayStr = new Date().toISOString().split('T')[0];
    return entryDate === todayStr;
  }

  public canAdd(entryDate: string): boolean {
    if (!this.currentSession) return false;
    const role = this.currentSession.profile.role;
    if (['superadmin', 'superstaff', 'owner'].includes(role)) return true;
    return this.isSameDay(entryDate);
  }

  public canEdit(entryDate: string): boolean {
    if (!this.currentSession) return false;
    const role = this.currentSession.profile.role;
    if (['superadmin', 'superstaff', 'owner'].includes(role)) return true;
    return this.isSameDay(entryDate);
  }

  public canDeleteJob(entryDate: string): boolean {
    if (!this.currentSession) return false;
    const role = this.currentSession.profile.role;
    if (['superadmin', 'superstaff', 'owner'].includes(role)) return true;
    if (role === 'manager') return this.isSameDay(entryDate);
    return false;
  }

  public canDeleteFinancial(entryDate: string): boolean {
    if (!this.currentSession) return false;
    const role = this.currentSession.profile.role;
    if (['superadmin', 'superstaff', 'owner'].includes(role)) return true;
    if (['manager', 'accountant'].includes(role)) return this.isSameDay(entryDate);
    return false;
  }

  public canViewReports(): boolean {
    if (!this.currentSession) return false;
    const role = this.currentSession.profile.role;
    return ['superadmin', 'superstaff', 'owner', 'manager', 'accountant'].includes(role);
  }

  // Audit Logging
  private logAudit(tableName: string, rowId: string | null, action: string, oldData: any, newData: any) {
    const entry: AuditLogEntry = {
      id: Date.now(),
      company_id: this.getEffectiveCompanyId(),
      table_name: tableName,
      row_id: rowId,
      action,
      old_data: oldData ? JSON.parse(JSON.stringify(oldData)) : null,
      new_data: newData ? JSON.parse(JSON.stringify(newData)) : null,
      user_id: this.currentSession?.user.id || null,
      at: new Date().toISOString(),
    };
    this.auditLog.unshift(entry);
    if (this.auditLog.length > 500) this.auditLog.pop();
  }

  // Companies Management (Super Admin & Super Staff)
  public getCompanies(): Company[] {
    return [...this.companies];
  }

  public getCompany(id: string): Company | null {
    return this.companies.find((c) => c.id === id) || null;
  }

  public createCompany(data: {
    name: string;
    code: string;
    valid_until: string;
    timezone?: string;
    currency?: string;
    owner_username: string;
    owner_full_name?: string;
    owner_password: string;
  }): { success: boolean; company?: Company; error?: string } {
    if (!this.currentSession || !['superadmin', 'superstaff'].includes(this.currentSession.profile.role)) {
      return { success: false, error: 'Forbidden: Super Admin or Super Staff required.' };
    }

    const codeUpper = data.code.trim().toUpperCase();
    if (this.companies.some((c) => c.code.toUpperCase() === codeUpper)) {
      return { success: false, error: 'A company with this code already exists.' };
    }

    const companyId = crypto.randomUUID();
    const newCompany: Company = {
      id: companyId,
      code: codeUpper,
      name: data.name.trim(),
      valid_until: data.valid_until,
      active: true,
      timezone: data.timezone || 'Asia/Dubai',
      currency: data.currency || 'AED',
      created_at: new Date().toISOString(),
    };
    this.companies.push(newCompany);

    // Create Owner Profile
    const ownerId = crypto.randomUUID();
    const ownerProfile: Profile = {
      id: ownerId,
      company_id: companyId,
      username: data.owner_username.trim().toLowerCase(),
      full_name: data.owner_full_name || 'Company Owner',
      role: 'owner',
      pay_type: 'none',
      pay_rate: 0,
      active: true,
    };
    this.profiles.push(ownerProfile);

    // Initialize Default Settings
    this.settings[companyId] = {
      company_id: companyId,
      work_types: ['Wash', 'Polish', 'Painting', 'Mechanical', 'Oil change', 'AC service', 'Other'],
      vehicle_types: ['Sedan', 'SUV', 'Hatchback', 'Pickup', 'Van', 'Bike'],
      expense_categories: ['Rent', 'Utilities', 'Materials', 'Transport', 'Maintenance', 'Food', 'Other'],
      thresholds: {
        margin_warn: 0.15,
        staff_warn: 0.40,
        staff_bad: 0.50,
        opex_warn: 0.20,
        opex_bad: 0.30,
        unpaid_warn: 0.10,
        unpaid_bad: 0.25,
        advance_warn: 0.15,
        sales_drop_warn: -0.10,
        sales_drop_bad: -0.25,
        expense_growth: 0.20,
      },
    };

    this.logAudit('companies', companyId, 'INSERT', null, newCompany);
    this.persist();
    return { success: true, company: newCompany };
  }

  public setSubscription(companyId: string, action: 'add_30_days' | 'set_date' | 'toggle_active', validUntil?: string, active?: boolean): { success: boolean; company?: Company; error?: string } {
    if (!this.currentSession || !['superadmin', 'superstaff'].includes(this.currentSession.profile.role)) {
      return { success: false, error: 'Forbidden: Super Admin or Super Staff required.' };
    }

    const company = this.companies.find((c) => c.id === companyId);
    if (!company) return { success: false, error: 'Company not found' };

    const oldCompany = { ...company };

    if (action === 'add_30_days') {
      const cur = new Date(company.valid_until);
      const now = new Date();
      const base = cur < now ? now : cur;
      base.setDate(base.getDate() + 30);
      company.valid_until = base.toISOString().split('T')[0];
      company.active = true;
    } else if (action === 'set_date' && validUntil) {
      company.valid_until = validUntil;
    } else if (action === 'toggle_active') {
      company.active = typeof active === 'boolean' ? active : !company.active;
    }

    this.logAudit('companies', company.id, 'UPDATE', oldCompany, company);
    this.persist();
    return { success: true, company };
  }

  public deleteCompany(companyId: string): { success: boolean; error?: string } {
    if (!this.currentSession || this.currentSession.profile.role !== 'superadmin') {
      return { success: false, error: 'Super Admin role required to delete a company.' };
    }

    const idx = this.companies.findIndex((c) => c.id === companyId);
    if (idx === -1) return { success: false, error: 'Company not found' };

    const old = this.companies[idx];
    this.companies.splice(idx, 1);
    this.profiles = this.profiles.filter((p) => p.company_id !== companyId);
    this.jobs = this.jobs.filter((j) => j.company_id !== companyId);
    this.expenses = this.expenses.filter((e) => e.company_id !== companyId);
    this.advances = this.advances.filter((a) => a.company_id !== companyId);
    this.attendance = this.attendance.filter((t) => t.company_id !== companyId);
    this.customerPayments = this.customerPayments.filter((cp) => cp.company_id !== companyId);
    this.customers = this.customers.filter((c) => c.company_id !== companyId);
    delete this.settings[companyId];

    this.logAudit('companies', companyId, 'DELETE', old, null);
    this.persist();
    return { success: true };
  }

  // Super Staff Management (Super Admin only)
  public getSuperStaffList(): Profile[] {
    return this.profiles.filter((p) => p.role === 'superstaff');
  }

  public createSuperStaff(username: string, fullName: string, password: string): { success: boolean; profile?: Profile; error?: string } {
    if (!this.currentSession || this.currentSession.profile.role !== 'superadmin') {
      return { success: false, error: 'Super Admin role required.' };
    }

    if (password.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }

    const cleanUser = username.trim().toLowerCase();
    if (this.profiles.some((p) => p.username === cleanUser && p.company_id === null)) {
      return { success: false, error: 'Super staff username already exists.' };
    }

    const profile: Profile = {
      id: crypto.randomUUID(),
      company_id: null,
      username: cleanUser,
      full_name: fullName.trim() || cleanUser,
      role: 'superstaff',
      pay_type: 'none',
      pay_rate: 0,
      active: true,
    };
    this.profiles.push(profile);
    this.logAudit('profiles', profile.id, 'INSERT', null, profile);
    this.persist();
    return { success: true, profile };
  }

  public removeSuperStaff(userId: string): { success: boolean; error?: string } {
    if (!this.currentSession || this.currentSession.profile.role !== 'superadmin') {
      return { success: false, error: 'Super Admin role required.' };
    }

    const idx = this.profiles.findIndex((p) => p.id === userId && p.role === 'superstaff');
    if (idx === -1) return { success: false, error: 'Super staff not found.' };

    const old = this.profiles[idx];
    this.profiles.splice(idx, 1);
    this.logAudit('profiles', userId, 'DELETE', old, null);
    this.persist();
    return { success: true };
  }

  // Profiles & Team Management
  public getCompanyProfiles(companyId?: string): Profile[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [];
    return this.profiles.filter((p) => p.company_id === cid);
  }

  public createCompanyUser(data: {
    username: string;
    full_name: string;
    role: AppRole;
    pay_type: 'none' | 'commission' | 'daily' | 'monthly';
    pay_rate: number;
    password: string;
    company_id?: string;
  }): { success: boolean; profile?: Profile; error?: string } {
    const cid = data.company_id || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    const callerRole = this.currentSession?.profile.role;
    const isPlatform = ['superadmin', 'superstaff'].includes(callerRole || '');
    const isOwner = callerRole === 'owner';

    if (!isPlatform && !isOwner) {
      return { success: false, error: 'Forbidden: Only Owner or Platform can add users.' };
    }

    if (data.password.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters.' };
    }

    const cleanUser = data.username.trim().toLowerCase();
    if (this.profiles.some((p) => p.company_id === cid && p.username === cleanUser)) {
      return { success: false, error: 'Username already taken in this company.' };
    }

    const newProfile: Profile = {
      id: crypto.randomUUID(),
      company_id: cid,
      username: cleanUser,
      full_name: data.full_name.trim(),
      role: data.role,
      pay_type: data.pay_type,
      pay_rate: Number(data.pay_rate) || 0,
      active: true,
    };
    this.profiles.push(newProfile);
    this.logAudit('profiles', newProfile.id, 'INSERT', null, newProfile);
    this.persist();
    return { success: true, profile: newProfile };
  }

  public resetUserPassword(userId: string, newPassword: string): { success: boolean; error?: string } {
    if (newPassword.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }

    const target = this.profiles.find((p) => p.id === userId);
    if (!target) return { success: false, error: 'User not found' };

    const callerRole = this.currentSession?.profile.role;
    const isPlatform = ['superadmin', 'superstaff'].includes(callerRole || '');
    const isOwner = callerRole === 'owner' && target.company_id === this.currentSession?.profile.company_id;

    if (!isPlatform && !isOwner) {
      return { success: false, error: 'Forbidden: Insufficient privileges to reset password.' };
    }

    this.logAudit('profiles', userId, 'PASSWORD_RESET', { user: target.username }, null);
    return { success: true };
  }

  public toggleUserActive(userId: string): { success: boolean; profile?: Profile; error?: string } {
    const target = this.profiles.find((p) => p.id === userId);
    if (!target) return { success: false, error: 'User not found' };

    const callerRole = this.currentSession?.profile.role;
    const isPlatform = ['superadmin', 'superstaff'].includes(callerRole || '');
    const isOwner = callerRole === 'owner' && target.company_id === this.currentSession?.profile.company_id;

    if (!isPlatform && !isOwner) {
      return { success: false, error: 'Forbidden' };
    }

    const old = { ...target };
    target.active = !target.active;
    this.logAudit('profiles', userId, 'UPDATE', old, target);
    this.persist();
    return { success: true, profile: target };
  }

  // Company Settings
  public getSettings(companyId?: string): CompanySettings {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid || !this.settings[cid]) {
      return {
        company_id: cid || '',
        work_types: ['Wash', 'Polish', 'Painting', 'Mechanical', 'Oil change', 'AC service', 'Other'],
        vehicle_types: ['Sedan', 'SUV', 'Hatchback', 'Pickup', 'Van', 'Bike'],
        expense_categories: ['Rent', 'Utilities', 'Materials', 'Transport', 'Maintenance', 'Food', 'Other'],
        thresholds: {
          margin_warn: 0.15,
          staff_warn: 0.40,
          staff_bad: 0.50,
          opex_warn: 0.20,
          opex_bad: 0.30,
          unpaid_warn: 0.10,
          unpaid_bad: 0.25,
          advance_warn: 0.15,
          sales_drop_warn: -0.10,
          sales_drop_bad: -0.25,
          expense_growth: 0.20,
        },
      };
    }
    return this.settings[cid];
  }

  public updateSettings(newSettings: Partial<CompanySettings>, companyId?: string): { success: boolean; error?: string } {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    const callerRole = this.currentSession?.profile.role;
    if (!['superadmin', 'superstaff', 'owner'].includes(callerRole || '')) {
      return { success: false, error: 'Only owners and platform staff can modify settings.' };
    }

    const old = this.settings[cid] || this.getSettings(cid);
    this.settings[cid] = {
      ...old,
      ...newSettings,
      company_id: cid,
    };
    this.logAudit('company_settings', cid, 'UPDATE', old, this.settings[cid]);
    this.persist();
    return { success: true };
  }

  // Customers & Credit Accounts
  public getCustomers(companyId?: string): Customer[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [];

    return this.customers
      .filter((c) => c.company_id === cid)
      .map((c) => {
        const jobs = this.jobs.filter((j) => j.customer_id === c.id);
        const pmts = this.customerPayments.filter((p) => p.customer_id === c.id);
        const totalJobs = jobs.reduce((sum, j) => sum + j.total, 0);
        const totalPmts = pmts.reduce((sum, p) => sum + p.amount, 0);
        const balance = totalJobs - totalPmts;

        let status: 'ok' | 'near_limit' | 'over_limit' = 'ok';
        if (c.credit_limit > 0) {
          if (balance > c.credit_limit) {
            status = 'over_limit';
          } else if (balance >= c.credit_limit * 0.8) {
            status = 'near_limit';
          }
        }

        return {
          ...c,
          total_jobs: totalJobs,
          total_payments: totalPmts,
          current_balance: balance,
          status,
        };
      });
  }

  public addCustomer(data: { name: string; mobile?: string; credit_limit: number; company_id?: string }): { success: boolean; customer?: Customer; error?: string } {
    const cid = data.company_id || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    const customer: Customer = {
      id: crypto.randomUUID(),
      company_id: cid,
      name: data.name.trim(),
      mobile: data.mobile?.trim() || null,
      credit_limit: Number(data.credit_limit) || 0,
      created_at: new Date().toISOString(),
    };
    this.customers.push(customer);
    this.logAudit('customers', customer.id, 'INSERT', null, customer);
    this.persist();
    return { success: true, customer };
  }

  public updateCustomer(id: string, data: { name: string; mobile?: string; credit_limit: number }): { success: boolean; customer?: Customer; error?: string } {
    const cust = this.customers.find((c) => c.id === id);
    if (!cust) return { success: false, error: 'Customer not found' };

    const old = { ...cust };
    cust.name = data.name.trim();
    cust.mobile = data.mobile?.trim() || null;
    cust.credit_limit = Number(data.credit_limit) || 0;

    this.logAudit('customers', cust.id, 'UPDATE', old, cust);
    this.persist();
    return { success: true, customer: cust };
  }

  public deleteCustomer(id: string): { success: boolean; error?: string } {
    const callerRole = this.currentSession?.profile.role;
    if (!['superadmin', 'superstaff', 'owner'].includes(callerRole || '')) {
      return { success: false, error: 'Only owners can delete customer accounts.' };
    }

    const hasJobs = this.jobs.some((j) => j.customer_id === id);
    if (hasJobs) {
      return { success: false, error: 'Cannot delete customer with existing jobs history.' };
    }

    const idx = this.customers.findIndex((c) => c.id === id);
    if (idx === -1) return { success: false, error: 'Customer not found' };

    const old = this.customers[idx];
    this.customers.splice(idx, 1);
    this.logAudit('customers', id, 'DELETE', old, null);
    this.persist();
    return { success: true };
  }

  public getCustomerStatement(customerId: string): {
    customer: Customer;
    items: Array<{
      date: string;
      description: string;
      debit: number;
      credit: number;
      balance: number;
    }>;
  } | null {
    const cust = this.customers.find((c) => c.id === customerId);
    if (!cust) return null;

    const jobs = this.jobs.filter((j) => j.customer_id === customerId).map((j) => ({
      date: j.entry_date,
      createdAt: j.created_at || j.entry_date,
      description: `${j.work_type} - ${j.vehicle_type} (${j.plate || 'No plate'})`,
      debit: j.total,
      credit: 0,
    }));

    const payments = this.customerPayments.filter((p) => p.customer_id === customerId).map((p) => ({
      date: p.entry_date,
      createdAt: p.created_at || p.entry_date,
      description: `Payment received: ${p.note || 'Cash/Transfer'}`,
      debit: 0,
      credit: p.amount,
    }));

    const combined = [...jobs, ...payments].sort((a, b) => {
      const cmp = a.date.localeCompare(b.date);
      if (cmp !== 0) return cmp;
      return a.createdAt.localeCompare(b.createdAt);
    });

    let running = 0;
    const items = combined.map((item) => {
      running += item.debit - item.credit;
      return {
        date: item.date,
        description: item.description,
        debit: item.debit,
        credit: item.credit,
        balance: running,
      };
    });

    return {
      customer: {
        ...cust,
        current_balance: running,
      },
      items,
    };
  }

  // Jobs (Vehicles)
  public getJobs(date?: string, companyId?: string): Job[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [];

    let list = this.jobs.filter((j) => j.company_id === cid);
    if (date) {
      list = list.filter((j) => j.entry_date === date);
    }

    return list.map((j) => {
      const staff = this.profiles.find((p) => p.id === j.staff_id);
      const cust = j.customer_id ? this.customers.find((c) => c.id === j.customer_id) : null;
      return {
        ...j,
        staff_name: staff?.full_name || 'Staff',
        customer_name: cust?.name,
      };
    });
  }

  public addJob(data: {
    entry_date: string;
    plate?: string;
    mobile?: string;
    work_type: string;
    vehicle_type: string;
    staff_id: string;
    price: number;
    extra_amount?: number;
    customer_id?: string | null;
    is_paid?: boolean;
    company_id?: string;
  }): { success: boolean; job?: Job; error?: string; overLimitWarning?: boolean } {
    const cid = data.company_id || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    if (!this.canAdd(data.entry_date)) {
      return { success: false, error: 'Non-owners can only add entries for today.' };
    }

    const price = Number(data.price) || 0;
    const extra = Number(data.extra_amount) || 0;
    const total = price + extra;

    let overLimitWarning = false;
    if (data.customer_id) {
      const cust = this.getCustomers(cid).find((c) => c.id === data.customer_id);
      if (cust && cust.credit_limit > 0) {
        const newBal = (cust.current_balance || 0) + total;
        if (newBal > cust.credit_limit) {
          overLimitWarning = true;
        }
      }
    }

    const job: Job = {
      id: crypto.randomUUID(),
      company_id: cid,
      entry_date: data.entry_date,
      plate: data.plate?.trim() || null,
      mobile: data.mobile?.trim() || null,
      work_type: data.work_type,
      vehicle_type: data.vehicle_type,
      staff_id: data.staff_id,
      price,
      extra_amount: extra,
      total,
      customer_id: data.customer_id || null,
      is_paid: data.customer_id ? false : Boolean(data.is_paid),
      created_by: this.currentSession?.user.id || data.staff_id,
      created_at: new Date().toISOString(),
    };

    this.jobs.unshift(job);
    this.logAudit('jobs', job.id, 'INSERT', null, job);
    this.persist();

    return { success: true, job, overLimitWarning };
  }

  public updateJob(
    id: string,
    data: {
      plate?: string;
      mobile?: string;
      work_type: string;
      vehicle_type: string;
      staff_id: string;
      price: number;
      extra_amount?: number;
      is_paid?: boolean;
      customer_id?: string | null;
      entry_date?: string;
    }
  ): { success: boolean; job?: Job; error?: string } {
    const job = this.jobs.find((j) => j.id === id);
    if (!job) return { success: false, error: 'Job not found' };

    if (!this.canEdit(job.entry_date)) {
      return { success: false, error: 'You cannot edit records from previous days.' };
    }

    const old = { ...job };
    const price = Number(data.price) || 0;
    const extra = Number(data.extra_amount) || 0;

    // Check entry_date change rule: Non-owners cannot change entry_date
    const callerRole = this.currentSession?.profile.role;
    if (data.entry_date && data.entry_date !== job.entry_date) {
      if (!['superadmin', 'superstaff', 'owner'].includes(callerRole || '')) {
        return { success: false, error: 'Non-owners cannot change entry_date.' };
      }
      job.entry_date = data.entry_date;
    }

    job.plate = data.plate?.trim() || null;
    job.mobile = data.mobile?.trim() || null;
    job.work_type = data.work_type;
    job.vehicle_type = data.vehicle_type;
    job.staff_id = data.staff_id;
    job.price = price;
    job.extra_amount = extra;
    job.total = price + extra;
    job.customer_id = data.customer_id || null;
    job.is_paid = data.customer_id ? false : Boolean(data.is_paid);

    this.logAudit('jobs', job.id, 'UPDATE', old, job);
    this.persist();
    return { success: true, job };
  }

  public deleteJob(id: string): { success: boolean; error?: string } {
    const job = this.jobs.find((j) => j.id === id);
    if (!job) return { success: false, error: 'Job not found' };

    if (!this.canDeleteJob(job.entry_date)) {
      return { success: false, error: 'You do not have permission to delete this vehicle record.' };
    }

    const idx = this.jobs.findIndex((j) => j.id === id);
    const old = this.jobs[idx];
    this.jobs.splice(idx, 1);
    this.logAudit('jobs', id, 'DELETE', old, null);
    this.persist();
    return { success: true };
  }

  // Expenses
  public getExpenses(date?: string, companyId?: string): Expense[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [];
    let list = this.expenses.filter((e) => e.company_id === cid);
    if (date) {
      list = list.filter((e) => e.entry_date === date);
    }
    return list;
  }

  public addExpense(data: {
    entry_date: string;
    category: string;
    description?: string;
    amount: number;
    company_id?: string;
  }): { success: boolean; expense?: Expense; error?: string } {
    const cid = data.company_id || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    if (!this.canAdd(data.entry_date)) {
      return { success: false, error: 'Expenses for past days can only be recorded by the Owner.' };
    }

    const expense: Expense = {
      id: crypto.randomUUID(),
      company_id: cid,
      entry_date: data.entry_date,
      category: data.category,
      description: data.description?.trim() || null,
      amount: Number(data.amount) || 0,
      created_by: this.currentSession?.user.id,
      created_at: new Date().toISOString(),
    };
    this.expenses.unshift(expense);
    this.logAudit('expenses', expense.id, 'INSERT', null, expense);
    this.persist();
    return { success: true, expense };
  }

  public deleteExpense(id: string): { success: boolean; error?: string } {
    const expense = this.expenses.find((e) => e.id === id);
    if (!expense) return { success: false, error: 'Expense not found' };

    if (!this.canDeleteFinancial(expense.entry_date)) {
      return { success: false, error: 'You do not have permission to delete this expense.' };
    }

    const idx = this.expenses.findIndex((e) => e.id === id);
    const old = this.expenses[idx];
    this.expenses.splice(idx, 1);
    this.logAudit('expenses', id, 'DELETE', old, null);
    this.persist();
    return { success: true };
  }

  // Staff Salary Advances
  public getAdvances(companyId?: string): Advance[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [];

    return this.advances
      .filter((a) => a.company_id === cid)
      .map((a) => {
        const staff = this.profiles.find((p) => p.id === a.staff_id);
        return {
          ...a,
          staff_name: staff?.full_name || 'Staff',
        };
      });
  }

  public addAdvance(data: {
    entry_date: string;
    staff_id: string;
    amount: number;
    note?: string;
    company_id?: string;
  }): { success: boolean; advance?: Advance; error?: string } {
    const cid = data.company_id || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    if (!this.canAdd(data.entry_date)) {
      return { success: false, error: 'Advances can only be entered for today.' };
    }

    const advance: Advance = {
      id: crypto.randomUUID(),
      company_id: cid,
      entry_date: data.entry_date,
      staff_id: data.staff_id,
      amount: Number(data.amount) || 0,
      note: data.note?.trim() || null,
      created_by: this.currentSession?.user.id,
      created_at: new Date().toISOString(),
    };
    this.advances.unshift(advance);
    this.logAudit('advances', advance.id, 'INSERT', null, advance);
    this.persist();
    return { success: true, advance };
  }

  public deleteAdvance(id: string): { success: boolean; error?: string } {
    const adv = this.advances.find((a) => a.id === id);
    if (!adv) return { success: false, error: 'Advance not found' };

    if (!this.canDeleteFinancial(adv.entry_date)) {
      return { success: false, error: 'Permission denied to delete this advance.' };
    }

    const idx = this.advances.findIndex((a) => a.id === id);
    const old = this.advances[idx];
    this.advances.splice(idx, 1);
    this.logAudit('advances', id, 'DELETE', old, null);
    this.persist();
    return { success: true };
  }

  // Attendance
  public getAttendance(date: string, companyId?: string): Attendance[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [];

    return this.attendance
      .filter((t) => t.company_id === cid && t.entry_date === date)
      .map((t) => {
        const staff = this.profiles.find((p) => p.id === t.staff_id);
        return {
          ...t,
          staff_name: staff?.full_name || 'Staff',
        };
      });
  }

  public markAttendance(staffId: string, entryDate: string, status: 'present' | 'leave', companyId?: string): { success: boolean; error?: string } {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    if (!this.canAdd(entryDate)) {
      return { success: false, error: 'Attendance for past dates can only be marked by the Owner.' };
    }

    const existing = this.attendance.find((t) => t.company_id === cid && t.staff_id === staffId && t.entry_date === entryDate);
    if (existing) {
      const old = { ...existing };
      existing.status = status;
      this.logAudit('attendance', existing.id, 'UPDATE', old, existing);
    } else {
      const newAtt: Attendance = {
        id: crypto.randomUUID(),
        company_id: cid,
        entry_date: entryDate,
        staff_id: staffId,
        status,
        created_at: new Date().toISOString(),
      };
      this.attendance.push(newAtt);
      this.logAudit('attendance', newAtt.id, 'INSERT', null, newAtt);
    }

    this.persist();
    return { success: true };
  }

  public markAllPresent(entryDate: string, companyId?: string): { success: boolean; error?: string } {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    if (!this.canAdd(entryDate)) {
      return { success: false, error: 'Attendance for past dates can only be marked by Owner.' };
    }

    const activeStaff = this.profiles.filter((p) => p.company_id === cid && p.active);
    for (const staff of activeStaff) {
      const existing = this.attendance.find((t) => t.company_id === cid && t.staff_id === staff.id && t.entry_date === entryDate);
      if (existing) {
        existing.status = 'present';
      } else {
        this.attendance.push({
          id: crypto.randomUUID(),
          company_id: cid,
          entry_date: entryDate,
          staff_id: staff.id,
          status: 'present',
          created_at: new Date().toISOString(),
        });
      }
    }
    this.persist();
    return { success: true };
  }

  // Customer Payments
  public getCustomerPayments(companyId?: string): CustomerPayment[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [];

    return this.customerPayments
      .filter((p) => p.company_id === cid)
      .map((p) => {
        const cust = this.customers.find((c) => c.id === p.customer_id);
        return {
          ...p,
          customer_name: cust?.name,
        };
      });
  }

  public recordCustomerPayment(data: {
    customer_id: string;
    entry_date: string;
    amount: number;
    note?: string;
    company_id?: string;
  }): { success: boolean; payment?: CustomerPayment; error?: string } {
    const cid = data.company_id || this.getEffectiveCompanyId();
    if (!cid) return { success: false, error: 'Company ID required' };

    const payment: CustomerPayment = {
      id: crypto.randomUUID(),
      company_id: cid,
      entry_date: data.entry_date,
      customer_id: data.customer_id,
      amount: Number(data.amount) || 0,
      note: data.note?.trim() || null,
      created_by: this.currentSession?.user.id,
      created_at: new Date().toISOString(),
    };
    this.customerPayments.unshift(payment);
    this.logAudit('customer_payments', payment.id, 'INSERT', null, payment);
    this.persist();
    return { success: true, payment };
  }

  // Audit Logs
  public getAuditLogs(companyId?: string): AuditLogEntry[] {
    const cid = companyId || this.getEffectiveCompanyId();
    if (!cid) return [...this.auditLog];
    return this.auditLog.filter((l) => l.company_id === cid || l.company_id === null);
  }

  // Comprehensive Report Engine (§8 & Migration 004 parity)
  public getCompanyReport(startDate: string, endDate: string, targetCompanyId?: string): ReportData | null {
    const cid = targetCompanyId || this.getEffectiveCompanyId();
    if (!cid) return null;

    if (!this.canViewReports()) {
      throw new Error('Access denied: Reports available to Owner, Accountant, and Platform roles only.');
    }

    const settings = this.getSettings(cid);
    const th = settings.thresholds;

    // Period length & previous period
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = end.getTime() - start.getTime();
    const periodDays = Math.max(1, Math.round(diffTime / (1000 * 60 * 60 * 24)) + 1);

    const prevEnd = new Date(start);
    prevEnd.setDate(prevEnd.getDate() - 1);
    const prevStart = new Date(prevEnd);
    prevStart.setDate(prevStart.getDate() - periodDays + 1);

    const prevStartStr = prevStart.toISOString().split('T')[0];
    const prevEndStr = prevEnd.toISOString().split('T')[0];

    // Jobs in period
    const pJobs = this.jobs.filter((j) => j.company_id === cid && j.entry_date >= startDate && j.entry_date <= endDate);
    const revenue = pJobs.reduce((sum, j) => sum + j.total, 0);
    const vehiclesCount = pJobs.length;
    const avgPerVehicle = vehiclesCount > 0 ? Math.round((revenue / vehiclesCount) * 100) / 100 : 0;

    // Collected cash = Paid walk-in jobs in period + Customer payments in period
    const paidWalkins = pJobs.filter((j) => j.customer_id === null && j.is_paid).reduce((sum, j) => sum + j.total, 0);
    const pCustPmts = this.customerPayments.filter((p) => p.company_id === cid && p.entry_date >= startDate && p.entry_date <= endDate);
    const custPmtsSum = pCustPmts.reduce((sum, p) => sum + p.amount, 0);
    const collected = paidWalkins + custPmtsSum;

    const unpaid = Math.max(0, revenue - collected);

    // Expenses in period
    const pExpenses = this.expenses.filter((e) => e.company_id === cid && e.entry_date >= startDate && e.entry_date <= endDate);
    const expenses = pExpenses.reduce((sum, e) => sum + e.amount, 0);

    // Customer accounts all-time
    const custAccounts = this.getCustomers(cid);
    const customerBalancesDue = custAccounts.reduce((sum, c) => sum + Math.max(0, c.current_balance || 0), 0);
    const overLimitCustomers = custAccounts.filter((c) => c.status === 'over_limit').map((c) => c.name);

    // Staff Payroll
    const companyStaff = this.profiles.filter((p) => p.company_id === cid && p.active);
    const staffPayroll: any[] = [];
    let totalSalary = 0;
    let totalAdvances = 0;

    for (const staff of companyStaff) {
      let grossSalary = 0;
      const sJobs = pJobs.filter((j) => j.staff_id === staff.id);
      const sJobsSales = sJobs.reduce((sum, j) => sum + j.total, 0);

      // Attendance in period
      const sAtt = this.attendance.filter((t) => t.company_id === cid && t.staff_id === staff.id && t.entry_date >= startDate && t.entry_date <= endDate);
      const presentDays = sAtt.filter((t) => t.status === 'present').length;
      const leaveDays = sAtt.filter((t) => t.status === 'leave').length;

      if (staff.pay_type === 'commission') {
        // Commission: sum(price) * rate% (PRICE ONLY, extra_amount excluded!)
        const priceSum = sJobs.reduce((sum, j) => sum + j.price, 0);
        grossSalary = priceSum * (staff.pay_rate / 100);
      } else if (staff.pay_type === 'daily') {
        // Daily: rate * present days
        grossSalary = staff.pay_rate * presentDays;
      } else if (staff.pay_type === 'monthly') {
        // Monthly: (rate / 30) * periodDays
        grossSalary = (staff.pay_rate / 30) * periodDays;
      }

      // Advances in period
      const sAdv = this.advances
        .filter((a) => a.company_id === cid && a.staff_id === staff.id && a.entry_date >= startDate && a.entry_date <= endDate)
        .reduce((sum, a) => sum + a.amount, 0);

      totalSalary += grossSalary;
      totalAdvances += sAdv;

      staffPayroll.push({
        staff_id: staff.id,
        full_name: staff.full_name,
        role: staff.role,
        pay_type: staff.pay_type,
        pay_rate: staff.pay_rate,
        jobs_count: sJobs.length,
        jobs_sales: Math.round(sJobsSales * 100) / 100,
        present_days: presentDays,
        leave_days: leaveDays,
        gross_salary: Math.round(grossSalary * 100) / 100,
        advances: Math.round(sAdv * 100) / 100,
        balance_to_pay: Math.round((grossSalary - sAdv) * 100) / 100,
      });
    }

    const netProfit = revenue - expenses - totalSalary;
    const cashProfit = collected - expenses - totalSalary;
    const netMargin = revenue > 0 ? Math.round((netProfit / revenue) * 10000) / 10000 : 0;

    // Previous Period Calculations
    const prevJobs = this.jobs.filter((j) => j.company_id === cid && j.entry_date >= prevStartStr && j.entry_date <= prevEndStr);
    const prevRevenue = prevJobs.reduce((sum, j) => sum + j.total, 0);
    const prevVehicles = prevJobs.length;

    const prevExpList = this.expenses.filter((e) => e.company_id === cid && e.entry_date >= prevStartStr && e.entry_date <= prevEndStr);
    const prevExpenses = prevExpList.reduce((sum, e) => sum + e.amount, 0);

    // Approximate prev salary
    let prevSalary = 0;
    for (const staff of companyStaff) {
      if (staff.pay_type === 'commission') {
        const psJobs = prevJobs.filter((j) => j.staff_id === staff.id);
        prevSalary += psJobs.reduce((sum, j) => sum + j.price, 0) * (staff.pay_rate / 100);
      } else if (staff.pay_type === 'daily') {
        const pPres = this.attendance.filter((t) => t.company_id === cid && t.staff_id === staff.id && t.entry_date >= prevStartStr && t.entry_date <= prevEndStr && t.status === 'present').length;
        prevSalary += staff.pay_rate * pPres;
      } else if (staff.pay_type === 'monthly') {
        prevSalary += (staff.pay_rate / 30) * periodDays;
      }
    }
    const prevNet = prevRevenue - prevExpenses - prevSalary;
    const salesGrowth = prevRevenue > 0 ? (revenue - prevRevenue) / prevRevenue : 0;
    const expGrowth = prevExpenses > 0 ? (expenses - prevExpenses) / prevExpenses : 0;

    // 10-Rule Diagnostic Health Score Engine (§8)
    let healthScore = 100;
    const warnings: DiagnosticWarning[] = [];

    // Rule 1: Net Margin
    if (netMargin < 0) {
      healthScore -= 20;
      warnings.push({
        code: 'margin_loss',
        level: 'red',
        title: 'Net Loss Incurred',
        description: `Net margin is ${(netMargin * 100).toFixed(1)}% (negative profit). Operating costs exceed total revenue.`,
        action: 'Audit operating overhead and review pricing tiers immediately.',
      });
    } else if (netMargin < th.margin_warn) {
      healthScore -= 8;
      warnings.push({
        code: 'margin_low',
        level: 'orange',
        title: 'Thin Profit Margin',
        description: `Net margin is ${(netMargin * 100).toFixed(1)}%, lower than the recommended ${(th.margin_warn * 100).toFixed(0)}%.`,
        action: 'Increase high-margin add-ons (polishing, detailing) and tighten material waste.',
      });
    }

    // Rule 2: Staff Cost Ratio
    if (revenue > 0) {
      const staffRatio = totalSalary / revenue;
      if (staffRatio > th.staff_bad) {
        healthScore -= 20;
        warnings.push({
          code: 'staff_bad',
          level: 'red',
          title: 'Severe Staff Cost Overrun',
          description: `Payroll consumes ${(staffRatio * 100).toFixed(1)}% of revenue (critical threshold: ${(th.staff_bad * 100).toFixed(0)}%).`,
          action: 'Shift daily wages to performance commission or optimize staffing schedule.',
        });
      } else if (staffRatio > th.staff_warn) {
        healthScore -= 8;
        warnings.push({
          code: 'staff_warn',
          level: 'orange',
          title: 'High Staff Cost',
          description: `Payroll is ${(staffRatio * 100).toFixed(1)}% of revenue (recommended below ${(th.staff_warn * 100).toFixed(0)}%).`,
          action: 'Increase daily job volume per technician to balance labor overhead.',
        });
      }

      // Rule 3: Operating Expenses Ratio
      const opexRatio = expenses / revenue;
      if (opexRatio > th.opex_bad) {
        healthScore -= 20;
        warnings.push({
          code: 'opex_bad',
          level: 'red',
          title: 'Excessive Operating Expenses',
          description: `Operating expenses represent ${(opexRatio * 100).toFixed(1)}% of revenue (critical ceiling: ${(th.opex_bad * 100).toFixed(0)}%).`,
          action: 'Renegotiate vendor supply agreements and eliminate non-essential expenses.',
        });
      } else if (opexRatio > th.opex_warn) {
        healthScore -= 8;
        warnings.push({
          code: 'opex_warn',
          level: 'orange',
          title: 'Elevated Operating Expenses',
          description: `Expenses stand at ${(opexRatio * 100).toFixed(1)}% of revenue (recommended below ${(th.opex_warn * 100).toFixed(0)}%).`,
          action: 'Monitor utility and material usage for leakage or unnecessary replenishment.',
        });
      }

      // Rule 4: Unpaid Ratio
      const unpaidRatio = unpaid / revenue;
      if (unpaidRatio > th.unpaid_bad) {
        healthScore -= 20;
        warnings.push({
          code: 'unpaid_bad',
          level: 'red',
          title: 'Critical Uncollected Revenue',
          description: `${(unpaidRatio * 100).toFixed(1)}% of revenue remains unpaid (critical ceiling: ${(th.unpaid_bad * 100).toFixed(0)}%).`,
          action: 'Instruct cashier to demand payment on delivery and collect credit invoices.',
        });
      } else if (unpaidRatio > th.unpaid_warn) {
        healthScore -= 8;
        warnings.push({
          code: 'unpaid_warn',
          level: 'orange',
          title: 'Uncollected Revenue Warning',
          description: `${(unpaidRatio * 100).toFixed(1)}% of revenue is pending collection.`,
          action: 'Follow up with walk-in customers and enforce stricter customer account terms.',
        });
      }
    }

    // Rule 5: Advances ÷ Salary
    if (totalSalary > 0 && totalAdvances / totalSalary > th.advance_warn) {
      healthScore -= 8;
      warnings.push({
        code: 'advances_high',
        level: 'orange',
        title: 'High Salary Advance Ratio',
        description: `Advances make up ${((totalAdvances / totalSalary) * 100).toFixed(1)}% of total earned salary (threshold: ${(th.advance_warn * 100).toFixed(0)}%).`,
        action: 'Cap advance disbursements to 15% of projected monthly earnings.',
      });
    }

    // Rule 6: Sales Drop vs Previous Period
    if (prevRevenue > 0) {
      if (salesGrowth <= th.sales_drop_bad) {
        healthScore -= 20;
        warnings.push({
          code: 'sales_plunge',
          level: 'red',
          title: 'Sharp Revenue Decline',
          description: `Sales plunged by ${Math.abs(salesGrowth * 100).toFixed(1)}% compared to the previous period.`,
          action: 'Launch marketing promotions and reach out to inactive fleet/corporate clients.',
        });
      } else if (salesGrowth <= th.sales_drop_warn) {
        healthScore -= 8;
        warnings.push({
          code: 'sales_dip',
          level: 'orange',
          title: 'Revenue Softening',
          description: `Sales fell by ${Math.abs(salesGrowth * 100).toFixed(1)}% compared to the previous period.`,
          action: 'Review peak service hours and offer bundle wash/polish discounts.',
        });
      }

      // Rule 7: Expenses Growing Faster than Sales
      if (expGrowth > th.expense_growth && expGrowth > salesGrowth + 0.1) {
        healthScore -= 20;
        warnings.push({
          code: 'expense_runaway',
          level: 'red',
          title: 'Expenses Outpacing Sales',
          description: `Expense growth (${(expGrowth * 100).toFixed(1)}%) is outpacing sales growth (${(salesGrowth * 100).toFixed(1)}%) by more than 10 points.`,
          action: 'Freeze discretionary spend and investigate supply purchase prices.',
        });
      }
    }

    // Rule 8: Single Expense Category Dominating (>40%)
    if (expenses > 0) {
      const catTotals: Record<string, number> = {};
      pExpenses.forEach((e) => {
        catTotals[e.category] = (catTotals[e.category] || 0) + e.amount;
      });
      for (const [cat, amt] of Object.entries(catTotals)) {
        if (amt / expenses > 0.4) {
          healthScore -= 8;
          warnings.push({
            code: 'category_spike',
            level: 'orange',
            title: `High Concentration in ${cat}`,
            description: `"${cat}" accounts for ${((amt / expenses) * 100).toFixed(1)}% of all expenses in this period.`,
            action: `Examine ${cat} invoices for potential supplier negotiations or waste reduction.`,
          });
          break;
        }
      }
    }

    // Rule 9: Any Customer Over Credit Limit
    if (overLimitCustomers.length > 0) {
      healthScore -= 20;
      warnings.push({
        code: 'customer_over_limit',
        level: 'red',
        title: 'Customer Credit Limits Breached',
        description: `${overLimitCustomers.length} customer(s) exceeded credit limit: ${overLimitCustomers.join(', ')}.`,
        action: 'Suspend further credit service for these accounts until arrears are settled.',
      });
    }

    // Rule 10: Customer Balances Above 50% of Period Revenue
    if (revenue > 0 && customerBalancesDue > 0.5 * revenue) {
      healthScore -= 8;
      warnings.push({
        code: 'receivables_high',
        level: 'orange',
        title: 'High Credit Exposure',
        description: `Outstanding customer debt (${customerBalancesDue.toFixed(2)}) exceeds 50% of period revenue (${revenue.toFixed(2)}).`,
        action: 'Issue account statements and follow up on credit collections.',
      });
    }

    healthScore = Math.max(0, Math.min(100, healthScore));
    const healthStatus: 'healthy' | 'fair' | 'at_risk' = healthScore >= 80 ? 'healthy' : healthScore >= 60 ? 'fair' : 'at_risk';

    // P&L categories
    const catMap: Record<string, number> = {};
    pExpenses.forEach((e) => {
      catMap[e.category] = (catMap[e.category] || 0) + e.amount;
    });
    const pnlCategories = Object.entries(catMap)
      .map(([category, amount]) => ({
        category,
        amount: Math.round(amount * 100) / 100,
        percent_of_revenue: revenue > 0 ? Math.round((amount / revenue) * 1000) / 10 : 0,
        percent_of_expenses: expenses > 0 ? Math.round((amount / expenses) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.amount - a.amount);

    // Daily breakdown for charts
    const dailyMap: Record<string, { revenue: number; expenses: number }> = {};
    pJobs.forEach((j) => {
      if (!dailyMap[j.entry_date]) dailyMap[j.entry_date] = { revenue: 0, expenses: 0 };
      dailyMap[j.entry_date].revenue += j.total;
    });
    pExpenses.forEach((e) => {
      if (!dailyMap[e.entry_date]) dailyMap[e.entry_date] = { revenue: 0, expenses: 0 };
      dailyMap[e.entry_date].expenses += e.amount;
    });
    const dailyChart = Object.keys(dailyMap)
      .sort()
      .map((date) => ({
        date,
        revenue: Math.round(dailyMap[date].revenue * 100) / 100,
        expenses: Math.round(dailyMap[date].expenses * 100) / 100,
      }));

    // Work type breakdown
    const wtMap: Record<string, { count: number; total: number }> = {};
    pJobs.forEach((j) => {
      if (!wtMap[j.work_type]) wtMap[j.work_type] = { count: 0, total: 0 };
      wtMap[j.work_type].count += 1;
      wtMap[j.work_type].total += j.total;
    });
    const salesByWorkType = Object.entries(wtMap)
      .map(([work_type, d]) => ({
        work_type,
        count: d.count,
        total: Math.round(d.total * 100) / 100,
        percent: revenue > 0 ? Math.round((d.total / revenue) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.total - a.total);

    // Vehicle type breakdown
    const vtMap: Record<string, { count: number; total: number }> = {};
    pJobs.forEach((j) => {
      if (!vtMap[j.vehicle_type]) vtMap[j.vehicle_type] = { count: 0, total: 0 };
      vtMap[j.vehicle_type].count += 1;
      vtMap[j.vehicle_type].total += j.total;
    });
    const salesByVehicleType = Object.entries(vtMap)
      .map(([vehicle_type, d]) => ({
        vehicle_type,
        count: d.count,
        total: Math.round(d.total * 100) / 100,
        percent: revenue > 0 ? Math.round((d.total / revenue) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.total - a.total);

    // Unpaid walk-in vehicles (oldest first)
    const unpaidVehicles = pJobs
      .filter((j) => j.customer_id === null && !j.is_paid)
      .sort((a, b) => a.entry_date.localeCompare(b.entry_date))
      .map((j) => {
        const staff = this.profiles.find((p) => p.id === j.staff_id);
        return {
          id: j.id,
          entry_date: j.entry_date,
          plate: j.plate,
          mobile: j.mobile,
          work_type: j.work_type,
          vehicle_type: j.vehicle_type,
          total: j.total,
          staff_name: staff?.full_name || 'Staff',
        };
      });

    return {
      kpis: {
        vehicles_count: vehiclesCount,
        revenue: Math.round(revenue * 100) / 100,
        avg_per_vehicle: avgPerVehicle,
        collected: Math.round(collected * 100) / 100,
        unpaid: Math.round(unpaid * 100) / 100,
        customer_balances_due: Math.round(customerBalancesDue * 100) / 100,
        expenses: Math.round(expenses * 100) / 100,
        total_salary: Math.round(totalSalary * 100) / 100,
        total_advances: Math.round(totalAdvances * 100) / 100,
        net_profit: Math.round(netProfit * 100) / 100,
        cash_profit: Math.round(cashProfit * 100) / 100,
        net_margin: netMargin,
      },
      previous_comparison: {
        prev_start_date: prevStartStr,
        prev_end_date: prevEndStr,
        prev_revenue: Math.round(prevRevenue * 100) / 100,
        prev_expenses: Math.round(prevExpenses * 100) / 100,
        prev_salary: Math.round(prevSalary * 100) / 100,
        prev_net_profit: Math.round(prevNet * 100) / 100,
        prev_vehicles_count: prevVehicles,
        sales_growth_pct: Math.round(salesGrowth * 1000) / 10,
        expense_growth_pct: Math.round(expGrowth * 1000) / 10,
      },
      health: {
        score: healthScore,
        status: healthStatus,
        warnings,
      },
      daily_chart: dailyChart,
      pnl_categories: pnlCategories,
      staff_payroll: staffPayroll,
      sales_by_work_type: salesByWorkType,
      sales_by_vehicle_type: salesByVehicleType,
      unpaid_vehicles: unpaidVehicles,
      customer_accounts: custAccounts.map((c) => ({
        id: c.id,
        name: c.name,
        mobile: c.mobile,
        credit_limit: c.credit_limit,
        current_balance: c.current_balance || 0,
        status: c.status || 'ok',
      })),
    };
  }

  // Cross-Company Summary (for Super Admin dashboard)
  public getCrossCompanySummaries(): Array<{
    company: Company;
    userCount: number;
    thisMonthRevenue: number;
    daysLeft: number;
    status: 'active' | 'suspended' | 'expired';
  }> {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    const monthPrefix = todayStr.substring(0, 7);

    return this.companies.map((comp) => {
      const users = this.profiles.filter((p) => p.company_id === comp.id);
      const mJobs = this.jobs.filter((j) => j.company_id === comp.id && j.entry_date.startsWith(monthPrefix));
      const revenue = mJobs.reduce((sum, j) => sum + j.total, 0);

      const validDate = new Date(comp.valid_until);
      const diffMs = validDate.getTime() - today.getTime();
      const daysLeft = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

      let status: 'active' | 'suspended' | 'expired' = 'active';
      if (!comp.active) {
        status = 'suspended';
      } else if (daysLeft < 0) {
        status = 'expired';
      }

      return {
        company: comp,
        userCount: users.length,
        thisMonthRevenue: Math.round(revenue * 100) / 100,
        daysLeft,
        status,
      };
    });
  }
}

// Global Singleton Provider
export const dataProvider = new DataProvider();
