'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Header } from '@/components/Header';
import { Navigation } from '@/components/Navigation';
import { ExpiryLockScreen } from '@/components/ExpiryLockScreen';
import { LoginScreen } from '@/components/screens/LoginScreen';
import { VehiclesScreen } from '@/components/screens/VehiclesScreen';
import { CustomersScreen } from '@/components/screens/CustomersScreen';
import { ExpensesScreen } from '@/components/screens/ExpensesScreen';
import { AdvancesScreen } from '@/components/screens/AdvancesScreen';
import { AttendanceScreen } from '@/components/screens/AttendanceScreen';
import { TeamScreen } from '@/components/screens/TeamScreen';
import { ReportsScreen } from '@/components/screens/ReportsScreen';
import { AdminScreen } from '@/components/screens/AdminScreen';

export default function Home() {
  const { session, activeTab, triggerRefresh } = useApp();

  // 1. Unauthenticated -> Login Screen
  if (!session) {
    return <LoginScreen />;
  }

  const role = session.profile.role;
  const isPlatform = ['superadmin', 'superstaff'].includes(role);
  const company = session.company;

  // 2. Subscription Expiry Enforced for Company Roles (§1 & §3)
  // Super Admin & Super Staff bypass the lock to assist & renew
  const todayStr = new Date().toISOString().split('T')[0];
  const isCompanyExpired = !isPlatform && company && (company.valid_until < todayStr || !company.active);

  if (isCompanyExpired) {
    return (
      <ExpiryLockScreen
        companyName={company.name}
        companyCode={company.code}
        validUntil={company.valid_until}
        onRenewed={triggerRefresh}
      />
    );
  }

  // 3. Active Screen Dispatcher
  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col pb-20 md:pb-8 selection:bg-blue-600 selection:text-white transition-colors duration-200">
      <Header />
      <Navigation />

      <main className="flex-1 w-full animate-in fade-in duration-150">
        {activeTab === 'vehicles' && <VehiclesScreen />}
        {activeTab === 'customers' && <CustomersScreen />}
        {activeTab === 'expenses' && <ExpensesScreen />}
        {activeTab === 'advances' && <AdvancesScreen />}
        {activeTab === 'attendance' && <AttendanceScreen />}
        {activeTab === 'team' && <TeamScreen />}
        {activeTab === 'reports' && <ReportsScreen />}
        {activeTab === 'admin' && isPlatform && <AdminScreen />}
      </main>
    </div>
  );
}
